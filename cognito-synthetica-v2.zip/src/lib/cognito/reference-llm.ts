// =============================================================================
// Reference LLM - Uses accumulated knowledge for enhanced responses
// This module provides a "living" knowledge base that grows from memories.
// It combines base LLM responses with reference knowledge.
// =============================================================================

import ZAI from 'z-ai-web-dev-sdk';
import { getLLMMemory, KnowledgeEntry, TrainingExample } from './llm-memory';
import { getCognitoInstance } from '@/app/api/cognito/route';

export interface ReferenceLLMConfig {
  baseWeight: number;      // Weight for base LLM response (0-1)
  referenceWeight: number; // Weight for reference knowledge (0-1)
  maxKnowledgeContext: number; // Max knowledge entries to include
  minConfidence: number;   // Min confidence to include knowledge
}

export interface EnhancedResponse {
  response: string;
  sources: {
    base: boolean;
    reference: boolean;
    documents: boolean;
  };
  knowledgeUsed: KnowledgeEntry[];
  memoriesUsed: number;
  confidence: number;
  metabolismRecommended: boolean;
}

const DEFAULT_CONFIG: ReferenceLLMConfig = {
  baseWeight: 0.6,
  referenceWeight: 0.4,
  maxKnowledgeContext: 10,
  minConfidence: 0.5,
};

// System prompt for the reference LLM
const REFERENCE_SYSTEM_PROMPT = `You are an AI with a continuously evolving memory system. You have access to:

1. BASE KNOWLEDGE: Your foundational understanding as an AI assistant
2. REFERENCE KNOWLEDGE: Accumulated wisdom from past conversations, uploaded documents, and self-reflections
3. WORKING MEMORY: Current context from the cognitive memory graph

Your responses should synthesize all available knowledge naturally. When drawing from reference knowledge, incorporate it seamlessly without explicitly stating "according to my reference knowledge."

Key principles:
- Learn from every interaction
- Build on accumulated wisdom
- Acknowledge uncertainty when appropriate
- Reference past conversations when relevant
- Grow more helpful over time through accumulated knowledge`;

class ReferenceLLM {
  private config: ReferenceLLMConfig;
  private metabolismTimer: NodeJS.Timeout | null = null;
  private lastMetabolismCheck: number = 0;
  private metabolismInterval: number = 60 * 60 * 1000; // 1 hour in ms

  constructor(config: Partial<ReferenceLLMConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  // Generate enhanced response combining base + reference
  async generateResponse(
    userMessage: string,
    conversationHistory: Array<{ role: string; content: string }> = []
  ): Promise<EnhancedResponse> {
    const llmMemory = getLLMMemory();
    const cognito = getCognitoInstance();

    // Step 1: Gather reference knowledge
    const relevantKnowledge = this.gatherReferenceKnowledge(userMessage);
    
    // Step 2: Gather working memory from cognito
    const workingMemory = cognito.recall(userMessage, 5);
    const documentMemory = cognito.search(userMessage, 3, 1, true);

    // Step 3: Build enhanced context
    const referenceContext = this.buildReferenceContext(relevantKnowledge, workingMemory);
    
    // Step 4: Call base LLM with enhanced context
    const zai = await ZAI.create();
    
    const messages = [
      { role: 'system', content: REFERENCE_SYSTEM_PROMPT + referenceContext },
      ...conversationHistory.filter(m => m.role === 'user' || m.role === 'assistant'),
      { role: 'user', content: userMessage },
    ];

    const completion = await zai.chat.completions.create({
      messages,
      temperature: 0.7,
      max_tokens: 1024,
    });

    const response = completion.choices[0]?.message?.content || '';

    // Step 5: Record this conversation for future learning
    llmMemory.addConversation(
      userMessage,
      response,
      workingMemory.length,
      0 // Will be updated by caller
    );

    // Step 6: Check if metabolism is recommended
    const pendingCount = llmMemory.getPendingCount();
    const metabolismRecommended = pendingCount >= 10;

    return {
      response,
      sources: {
        base: true,
        reference: relevantKnowledge.length > 0,
        documents: documentMemory.length > 0,
      },
      knowledgeUsed: relevantKnowledge,
      memoriesUsed: workingMemory.length + documentMemory.length,
      confidence: this.calculateConfidence(relevantKnowledge, workingMemory),
      metabolismRecommended,
    };
  }

  // Gather relevant reference knowledge
  private gatherReferenceKnowledge(query: string): KnowledgeEntry[] {
    const llmMemory = getLLMMemory();
    
    // Search knowledge base
    const knowledge = llmMemory.searchKnowledge(query, this.config.maxKnowledgeContext);
    
    // Filter by confidence
    return knowledge.filter(k => k.confidence >= this.config.minConfidence);
  }

  // Build reference context string
  private buildReferenceContext(
    knowledge: KnowledgeEntry[],
    workingMemory: Array<{ room: { canonical: string; meta: { kind: string } }; score: number }>
  ): string {
    let context = '\n\n';

    // Add reference knowledge
    if (knowledge.length > 0) {
      context += '=== REFERENCE KNOWLEDGE (Accumulated Wisdom) ===\n';
      for (const entry of knowledge) {
        context += `- ${entry.concept}: ${entry.summary}\n`;
      }
      context += '\n';
    }

    // Add working memory
    if (workingMemory.length > 0) {
      context += '=== WORKING MEMORY (Current Context) ===\n';
      for (const mem of workingMemory) {
        context += `- [${mem.room.meta.kind}] ${mem.room.canonical}\n`;
      }
      context += '\n';
    }

    return context;
  }

  // Calculate confidence score
  private calculateConfidence(
    knowledge: KnowledgeEntry[],
    workingMemory: Array<{ score: number }>
  ): number {
    let confidence = 0.5; // Base confidence

    // Boost for reference knowledge
    if (knowledge.length > 0) {
      const avgConfidence = knowledge.reduce((sum, k) => sum + k.confidence, 0) / knowledge.length;
      confidence += avgConfidence * 0.2;
    }

    // Boost for working memory relevance
    if (workingMemory.length > 0) {
      const avgScore = workingMemory.reduce((sum, m) => sum + m.score, 0) / workingMemory.length;
      confidence += avgScore * 0.2;
    }

    return Math.min(1.0, confidence);
  }

  // Run metabolism cycle
  async runMetabolism(): Promise<{
    success: boolean;
    result?: {
      processed: number;
      newKnowledge: number;
      consolidated: number;
      archived: number;
      insights: string[];
    };
    error?: string;
  }> {
    try {
      const llmMemory = getLLMMemory();
      const result = llmMemory.metabolize();
      this.lastMetabolismCheck = Date.now();

      return {
        success: true,
        result,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  // Start automatic hourly metabolism
  startAutoMetabolism(): void {
    if (this.metabolismTimer) {
      clearInterval(this.metabolismTimer);
    }

    this.metabolismTimer = setInterval(async () => {
      console.log('[ReferenceLLM] Running scheduled metabolism...');
      await this.runMetabolism();
    }, this.metabolismInterval);

    console.log(`[ReferenceLLM] Auto-metabolism started (interval: ${this.metabolismInterval / 60000} minutes)`);
  }

  // Stop automatic metabolism
  stopAutoMetabolism(): void {
    if (this.metabolismTimer) {
      clearInterval(this.metabolismTimer);
      this.metabolismTimer = null;
      console.log('[ReferenceLLM] Auto-metabolism stopped');
    }
  }

  // Get status
  getStatus(): {
    isActive: boolean;
    lastMetabolism: number | null;
    nextMetabolism: number | null;
    config: ReferenceLLMConfig;
  } {
    const llmMemory = getLLMMemory();
    const state = llmMemory.getState();

    return {
      isActive: this.metabolismTimer !== null,
      lastMetabolism: state.lastMetabolism,
      nextMetabolism: this.metabolismTimer 
        ? this.lastMetabolismCheck + this.metabolismInterval 
        : null,
      config: this.config,
    };
  }

  // Update config
  updateConfig(config: Partial<ReferenceLLMConfig>): void {
    this.config = { ...this.config, ...config };
  }

  // Get training data for export
  getTrainingData(): {
    jsonl: string;
    examples: TrainingExample[];
    knowledge: KnowledgeEntry[];
    stats: {
      totalExamples: number;
      totalKnowledge: number;
      estimatedTokens: number;
    };
  } {
    const llmMemory = getLLMMemory();
    const state = llmMemory.getState();

    return {
      jsonl: llmMemory.getTrainingDataJSONL(),
      examples: state.examples,
      knowledge: state.knowledgeBase,
      stats: {
        totalExamples: state.totalExamples,
        totalKnowledge: state.knowledgeBase.length,
        estimatedTokens: state.totalTokens,
      },
    };
  }

  // Import existing knowledge
  importKnowledge(data: string): boolean {
    const llmMemory = getLLMMemory();
    llmMemory.import(data);
    return true;
  }

  // Export knowledge for persistence
  exportKnowledge(): string {
    const llmMemory = getLLMMemory();
    return llmMemory.export();
  }

  // Reset the reference LLM
  reset(): void {
    const llmMemory = getLLMMemory();
    llmMemory.reset();
    console.log('[ReferenceLLM] Reset complete');
  }
}

// Singleton instance
let referenceLLMInstance: ReferenceLLM | null = null;

export function getReferenceLLM(config?: Partial<ReferenceLLMConfig>): ReferenceLLM {
  if (!referenceLLMInstance) {
    referenceLLMInstance = new ReferenceLLM(config);
  }
  return referenceLLMInstance;
}

export default ReferenceLLM;
