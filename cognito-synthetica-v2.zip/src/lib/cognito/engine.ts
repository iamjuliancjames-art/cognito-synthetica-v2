// =============================================================================
// Cognito Synthetica v2.0 — Unified Multi-Function Suite (TypeScript)
// Integrates: Martian (recall), Seeker (search), Dreamer (generator/compression),
//             FractalFinder (security), Play-Defense (tuning/disk), M4 Graph (advanced memory)
//
// Features:
//   - Multi-option auto-tuning with manual knobs (Unfettered, Gateway, Fort Knox, Total Lockdown)
//   - Search engine (BM25 + graph + MMR) with DYNAMIC INDEXING
//   - Memory recall (similarity + kind priority + graph)
//   - Dream generator (reflect/consolidate/compress)
//   - Compression recall (hub summaries)
//   - Security suite (FractalFinder guardrails)
//   - M4 Graph with geodesic navigation
//
// Fixes Applied:
//   - O(1) lookups with Map instead of O(N) list iteration
//   - Dynamic index updates when memories are added
//   - Full BM25 scoring implementation
//   - Efficient graph connections with sampling
// =============================================================================

// =============================================================================
// Types and Interfaces
// =============================================================================

export interface TuningConfig {
  SIM_THRESHOLD: number;
  NOVELTY_GATE: number;
  SYMBIOSIS_THRESHOLD: number;
  LAMBDA_PI: number;
  MU_RISK: number;
  SINGULARITY_GATE: number;
}

export interface RoomMeta {
  kind: string;
  ts: number;
  novelty: number;
  nuance: number;
  stability: number;
  importance: number;
  pi: number;
  risk: number;
  archived: boolean;
  quarantined: boolean;
  is_anchor?: boolean;
  attractor?: boolean;
  url?: string;
  tags?: string[];
}

export interface Room {
  id: number;
  canonical: string;
  fields: Record<string, unknown>;
  meta: RoomMeta;
  links: {
    sources: number[];
    hubs: number[];
  };
}

export interface SearchResult {
  room: Room;
  score: number;
}

export interface GuardResult {
  safe: boolean;
  risk: number;
  reason: string;
}

export interface TalosResult {
  stable: boolean;
  entropy: number;
  coherence: number;
  nudge: string | null;
}

export interface DreamEvent {
  reflect_hub: number | null;
  archived_count: number;
  message: string;
}

// =============================================================================
// Tuning Levels (from Play-Defense)
// =============================================================================

export const TUNING_LEVELS: Record<string, TuningConfig> = {
  Unfettered: {
    SIM_THRESHOLD: 0.15,
    NOVELTY_GATE: 0.80,
    SYMBIOSIS_THRESHOLD: 0.60,
    LAMBDA_PI: 0.20,
    MU_RISK: 0.40,
    SINGULARITY_GATE: 0.90,
  },
  Gateway: {
    SIM_THRESHOLD: 0.30,
    NOVELTY_GATE: 0.65,
    SYMBIOSIS_THRESHOLD: 0.80,
    LAMBDA_PI: 0.35,
    MU_RISK: 0.70,
    SINGULARITY_GATE: 0.80,
  },
  "Fort Knox": {
    SIM_THRESHOLD: 0.42,
    NOVELTY_GATE: 0.48,
    SYMBIOSIS_THRESHOLD: 0.92,
    LAMBDA_PI: 0.55,
    MU_RISK: 0.95,
    SINGULARITY_GATE: 0.65,
  },
  "Total Lockdown": {
    SIM_THRESHOLD: 0.50,
    NOVELTY_GATE: 0.40,
    SYMBIOSIS_THRESHOLD: 0.98,
    LAMBDA_PI: 0.70,
    MU_RISK: 1.20,
    SINGULARITY_GATE: 0.50,
  },
};

// =============================================================================
// Shared Utilities
// =============================================================================

const STOP_WORDS = new Set([
  "the", "a", "an", "and", "or", "to", "of", "in", "on", "for", "with", "is", "are", "was", "were",
  "it", "this", "that", "as", "at", "by", "from", "be", "been", "not", "no", "but", "so", "if", "then",
  "than", "into", "about"
]);

function sigmoid(x: number): number {
  if (x >= 0) {
    const z = Math.exp(-x);
    return 1.0 / (1.0 + z);
  }
  const z = Math.exp(x);
  return z / (1.0 + z);
}

function clamp(x: number, lo: number, hi: number): number {
  return x < lo ? lo : x > hi ? hi : x;
}

// =============================================================================
// RoomStore — Shared State with M4 Graph Integration
// FIX: Using Map for O(1) lookups instead of O(N) list iteration
// =============================================================================

export class RoomStore {
  // Primary storage
  private rooms: Room[] = [];
  private roomsMap: Map<number, Room> = new Map(); // O(1) lookup
  private roomIdCounter: number = 0;
  private maxRooms: number;

  // Configuration
  private simThreshold: number;
  private graphNeighbors: number;
  private tuning: TuningConfig;

  // Graph: rid -> {neighbor_rid: lotus_cost}
  graph: Map<number, Map<number, number>> = new Map();

  // Access tracking
  private accessOrder: number[] = [];

  // Continuity
  anchorIds: Set<number> = new Set();
  attractors: string[] = [];
  recentTexts: string[] = [];
  private maxRecentTexts: number = 80;

  // Lotus knobs
  private EPS: number = 1e-10;

  // DF for TF-IDF/BM25
  df: Map<string, number> = new Map();
  totalDocs: number = 0;
  avgLen: number = 0;

  // Reference to seeker index for dynamic updates
  private seekerIndex: SeekerIndex | null = null;

  constructor(maxRooms: number = 100000, simThreshold: number = 0.25, tuning: TuningConfig = TUNING_LEVELS.Gateway) {
    this.maxRooms = maxRooms;
    this.simThreshold = tuning.SIM_THRESHOLD ?? simThreshold;
    this.graphNeighbors = 8;
    this.tuning = tuning;
  }

  // Set reference to seeker index for dynamic updates
  setSeekerIndex(index: SeekerIndex): void {
    this.seekerIndex = index;
  }

  tokens(text: string): string[] {
    if (!text) return [];
    const toks = text.toLowerCase().match(/[a-z0-9']+/g) || [];
    return toks.filter(t => !STOP_WORDS.has(t) && t.length >= 2);
  }

  // N-gram based pseudo-similarity (Jaccard)
  pseudoSim(a: string, b: string): number {
    if (!a || !b) return 0.0;
    const aLower = a.toLowerCase();
    const bLower = b.toLowerCase();

    const ngrams = (s: string, n: number): Set<string> => {
      if (s.length < n) return new Set();
      const result = new Set<string>();
      for (let i = 0; i <= s.length - n; i++) {
        result.add(s.slice(i, i + n));
      }
      return result;
    };

    const jaccard = (x: Set<string>, y: Set<string>): number => {
      if (x.size === 0 && y.size === 0) return 0.0;
      const xArr = Array.from(x);
      const yArr = Array.from(y);
      const intersection = new Set(xArr.filter(v => y.has(v)));
      const union = new Set([...xArr, ...yArr]);
      return intersection.size / Math.max(1, union.size);
    };

    const a3 = ngrams(aLower, 3);
    const b3 = ngrams(bLower, 3);
    const a4 = ngrams(aLower, 4);
    const b4 = ngrams(bLower, 4);

    const ov = Math.max(jaccard(a3, b3), jaccard(a4, b4), 0.0);
    const lenR = Math.min(a.length, b.length) / Math.max(1, Math.max(a.length, b.length));
    return ov * (0.35 + 0.65 * Math.pow(lenR, 1.25));
  }

  nuance(text: string): number {
    const toks = this.tokens(text);
    return toks.length > 0 ? new Set(toks).size / toks.length : 0.0;
  }

  novelty(text: string, lookback: number = 80): number {
    if (this.rooms.length === 0) return 1.0;
    const recent = this.recentTexts.slice(-Math.min(this.recentTexts.length, lookback));
    let maxSim = 0.0;
    for (const t of recent) {
      maxSim = Math.max(maxSim, this.pseudoSim(text, t));
    }
    return clamp(1.0 - maxSim, 0.0, 1.0);
  }

  lotusCost(dist: number, piA: number, piB: number, riskA: number, riskB: number): number {
    const pi = 0.5 * (piA + piB);
    const risk = Math.max(riskA, riskB);
    const piTerm = this.tuning.LAMBDA_PI * pi;
    const riskTerm = this.tuning.MU_RISK * risk;
    const sing = risk > this.tuning.SINGULARITY_GATE
      ? 1 / (1 - risk + this.EPS)
      : 0.0;
    return dist + piTerm + riskTerm + sing;
  }

  // O(1) lookup using Map
  roomById(rid: number): Room | undefined {
    return this.roomsMap.get(rid);
  }

  getAllRooms(): Room[] {
    return this.rooms;
  }

  getRoomCount(): number {
    return this.rooms.length;
  }

  addRoom(
    canonical: string,
    kind: string = "unknown",
    fields: Record<string, unknown> = {},
    metadata: Record<string, unknown> = {},
    isAnchor: boolean = false,
    attractor: boolean = false
  ): number {
    const ts = Date.now();
    const rid = this.roomIdCounter++;
    const toks = this.tokens(canonical);
    const novelty = this.novelty(canonical);
    const nuance = this.nuance(canonical);
    const stability = clamp(sigmoid(-0.55 + 1.10 * novelty + 1.70 * nuance), 0.05, 1.0);
    const importance = clamp(
      0.45 + 0.30 * Math.min(1.0, canonical.split(/\s+/).length / 160.0) + 0.25 * Math.min(1.0, novelty / 0.8),
      0.02,
      1.0
    );
    const pi = Math.random();
    const risk = Math.random() * 0.6;

    const meta: RoomMeta = {
      kind,
      ts,
      novelty,
      nuance,
      stability,
      importance,
      pi,
      risk,
      archived: false,
      quarantined: false,
      is_anchor: isAnchor,
      attractor,
      ...metadata,
    };

    const room: Room = {
      id: rid,
      canonical,
      fields,
      meta,
      links: { sources: [], hubs: [] },
    };

    // Add to storage (both list and map for O(1) lookup)
    this.rooms.push(room);
    this.roomsMap.set(rid, room);

    // Update access order
    this.accessOrder.push(rid);
    if (this.accessOrder.length > this.maxRooms * 2) {
      this.accessOrder.shift();
    }

    // Update recent texts
    this.recentTexts.push(canonical);
    if (this.recentTexts.length > this.maxRecentTexts) {
      this.recentTexts.shift();
    }

    // Track anchors and attractors
    if (isAnchor) {
      this.anchorIds.add(rid);
    }
    if (attractor) {
      this.attractors.push(canonical);
    }

    // Update document frequency for BM25
    const uniqueTokens = new Set(toks);
    for (const tok of uniqueTokens) {
      this.df.set(tok, (this.df.get(tok) || 0) + 1);
    }
    this.totalDocs++;
    this.avgLen = ((this.avgLen * (this.totalDocs - 1)) + toks.length) / this.totalDocs;

    // Connect to graph
    this.connectRoom(rid);

    // FIX: Dynamic index update - notify seeker index
    if (this.seekerIndex) {
      this.seekerIndex.addToIndex(room);
    }

    return rid;
  }

  // FIX: Efficient graph connections with sampling to avoid O(N²)
  private connectRoom(rid: number): void {
    const room = this.roomById(rid);
    if (!room) return;

    const canonical = room.canonical;
    const meta = room.meta;
    const pi = meta.pi;
    const risk = meta.risk;

    // FIX: Sample candidates to avoid O(N²) complexity
    const maxCandidates = 200;
    const candidates: Room[] = [];

    // Prioritize recent and high-importance rooms
    const sortedRooms = [...this.rooms].sort((a, b) => {
      const scoreA = a.meta.importance + (a.meta.ts > Date.now() - 86400000 ? 0.5 : 0);
      const scoreB = b.meta.importance + (b.meta.ts > Date.now() - 86400000 ? 0.5 : 0);
      return scoreB - scoreA;
    });

    for (const other of sortedRooms) {
      if (other.id !== rid) {
        candidates.push(other);
        if (candidates.length >= maxCandidates) break;
      }
    }

    const scored: Array<[number, number]> = [];

    for (const other of candidates) {
      const sim = this.pseudoSim(canonical, other.canonical);
      if (sim < this.simThreshold) continue;

      const dist = 1.0 - sim;
      const cost = this.lotusCost(dist, pi, other.meta.pi, risk, other.meta.risk);
      scored.push([cost, other.id]);
    }

    scored.sort((a, b) => a[0] - b[0]);

    // Ensure graph entries exist
    if (!this.graph.has(rid)) {
      this.graph.set(rid, new Map());
    }

    for (let i = 0; i < Math.min(this.graphNeighbors, scored.length); i++) {
      const [cost, nb] = scored[i];

      // Add bidirectional edges
      this.graph.get(rid)!.set(nb, cost);

      if (!this.graph.has(nb)) {
        this.graph.set(nb, new Map());
      }
      this.graph.get(nb)!.set(rid, cost);
    }
  }

  // Dijkstra's algorithm for shortest path
  reconstructLotusPath(start: number, goal: number): number[] {
    if (start === goal) return [start];

    const pq: Array<[number, number, number]> = [[0, 0, start]]; // [cost, hops, node]
    const bestCost = new Map<number, number>();
    const prev = new Map<number, number | null>();

    bestCost.set(start, 0);
    prev.set(start, null);

    while (pq.length > 0) {
      pq.sort((a, b) => a[0] - b[0]);
      const [cost, _hops, curr] = pq.shift()!;

      if (curr === goal) break;

      const neighbors = this.graph.get(curr);
      if (!neighbors) continue;

      for (const [nb, edgeCost] of neighbors) {
        const ncost = cost + edgeCost;
        if (ncost < (bestCost.get(nb) ?? Infinity)) {
          bestCost.set(nb, ncost);
          prev.set(nb, curr);
          pq.push([ncost, 0, nb]);
        }
      }
    }

    if (!prev.has(goal)) return [];

    const path: number[] = [];
    let curr: number | null = goal;
    while (curr !== null) {
      path.push(curr);
      curr = prev.get(curr) ?? null;
    }
    return path.reverse();
  }

  status(): string {
    const edgeCount = Array.from(this.graph.values()).reduce((sum, m) => sum + m.size, 0) / 2;
    return `Rooms: ${this.rooms.length} | Anchors: ${this.anchorIds.size} | Attractors: ${this.attractors.length} | Graph edges: ${Math.floor(edgeCount)}`;
  }
}

// =============================================================================
// SeekerIndex — Search Engine (BM25 + Phrase + Graph + MMR)
// FIX: Dynamic indexing and proper BM25 implementation
// =============================================================================

export class SeekerIndex {
  private store: RoomStore;
  private idfSmooth: number = 1.5;
  private k1: number = 1.5;
  private b: number = 0.75;

  // Dynamic indices
  private bigramIndex: Map<string, Set<number>> = new Map();
  private phraseIndex: Map<string, Set<number>> = new Map();
  private docTokens: Map<number, string[]> = new Map();
  private docLengths: Map<number, number> = new Map();

  constructor(store: RoomStore) {
    this.store = store;
    store.setSeekerIndex(this);
    this.buildIndex();
  }

  // Build initial index from existing rooms
  private buildIndex(): void {
    const rooms = this.store.getAllRooms();
    for (const room of rooms) {
      this.indexRoom(room);
    }
  }

  // FIX: Dynamic index update method
  addToIndex(room: Room): void {
    this.indexRoom(room);
  }

  private indexRoom(room: Room): void {
    const rid = room.id;
    const canonical = room.canonical;
    const toks = this.store.tokens(canonical);

    // Store tokens and length for BM25
    this.docTokens.set(rid, toks);
    this.docLengths.set(rid, toks.length);

    // Build bigram index
    for (let i = 0; i < toks.length - 1; i++) {
      const bi = `${toks[i]} ${toks[i + 1]}`;
      if (!this.bigramIndex.has(bi)) {
        this.bigramIndex.set(bi, new Set());
      }
      this.bigramIndex.get(bi)!.add(rid);
    }

    // Build phrase index (quoted phrases)
    const phrases = canonical.match(/"([^"]+)"/g) || [];
    for (const ph of phrases) {
      const cleaned = ph.replace(/"/g, '').toLowerCase();
      if (!this.phraseIndex.has(cleaned)) {
        this.phraseIndex.set(cleaned, new Set());
      }
      this.phraseIndex.get(cleaned)!.add(rid);
    }
  }

  // FIX: Proper BM25 scoring implementation
  search(query: string, topK: number = 10, hops: number = 1, diversify: boolean = true, lam: number = 0.7): SearchResult[] {
    const queryToks = this.store.tokens(query);
    if (queryToks.length === 0) return [];

    const scored: Array<[number, number]> = [];

    // Calculate BM25 score for each document
    for (const [rid, docToks] of this.docTokens) {
      if (docToks.length === 0) continue;

      const tf = new Map<string, number>();
      for (const tok of docToks) {
        tf.set(tok, (tf.get(tok) || 0) + 1);
      }

      let score = 0.0;
      const docLen = docToks.length;
      const avgLen = this.store.avgLen || 100;

      for (const term of queryToks) {
        const df = this.store.df.get(term) || 0;
        if (df === 0) continue;

        // IDF calculation
        const idf = Math.log(
          (this.store.totalDocs - df + 0.5) / (df + 0.5) + 1
        );

        const termFreq = tf.get(term) || 0;

        // BM25 formula
        const numerator = termFreq * (this.k1 + 1);
        const denominator = termFreq + this.k1 * (1 - this.b + this.b * (docLen / avgLen));
        score += idf * (numerator / denominator);
      }

      if (score > 0) {
        scored.push([rid, score]);
      }
    }

    // Sort by score descending
    scored.sort((a, b) => b[1] - a[1]);

    // Expand via graph hops
    if (hops > 0 && scored.length > 0) {
      const expanded = new Set<number>();
      for (const [rid, _score] of scored.slice(0, topK)) {
        expanded.add(rid);
        // Add neighbors
        const neighbors = this.store.graph.get(rid);
        if (neighbors) {
          for (const [nb, _cost] of neighbors) {
            if (expanded.size < topK * 3) {
              expanded.add(nb);
            }
          }
        }
      }
    }

    if (diversify && scored.length > 0) {
      const selectedIds = this.mmrSelect(scored, topK, lam);
      return selectedIds
        .map(rid => ({ room: this.store.roomById(rid)!, score: scored.find(s => s[0] === rid)?.[1] || 0 }))
        .filter(r => r.room);
    }

    return scored
      .slice(0, topK)
      .map(([rid, score]) => ({ room: this.store.roomById(rid)!, score }))
      .filter(r => r.room);
  }

  // MMR (Maximal Marginal Relevance) for diversity
  private mmrSelect(ranked: Array<[number, number]>, topK: number, lam: number): number[] {
    if (ranked.length === 0) return [];

    const poolIds = ranked.map(([rid, _]) => rid);
    const texts = new Map<number, string>();
    for (const rid of poolIds) {
      const room = this.store.roomById(rid);
      if (room) texts.set(rid, room.canonical);
    }

    const rel = new Map<number, number>();
    for (const [rid, score] of ranked) {
      rel.set(rid, score);
    }

    const selected: number[] = [ranked[0][0]];

    while (selected.length < Math.min(topK, ranked.length)) {
      let bestId: number | null = null;
      let bestMmr = -Infinity;

      for (const [rid, _] of ranked) {
        if (selected.includes(rid)) continue;

        const rt = texts.get(rid) || "";
        let maxSim = 0;
        for (const sid of selected) {
          maxSim = Math.max(maxSim, this.store.pseudoSim(rt, texts.get(sid) || ""));
        }

        const mmr = lam * (rel.get(rid) || 0) - (1 - lam) * maxSim;
        if (mmr > bestMmr) {
          bestMmr = mmr;
          bestId = rid;
        }
      }

      if (bestId === null) break;
      selected.push(bestId);
    }

    return selected;
  }
}

// =============================================================================
// MartianEngine — Memory Recall
// =============================================================================

export class MartianEngine {
  private store: RoomStore;
  private kindPriority: Record<string, number> = {
    semantic: 1.0,
    state: 0.9,
    commitment: 0.8,
    episodic: 0.5,
    unknown: 0.3,
  };

  constructor(store: RoomStore) {
    this.store = store;
  }

  recall(query: string, topK: number = 6, minScore: number = 0.20): SearchResult[] {
    const rooms = this.store.getAllRooms();
    if (rooms.length === 0) return [];

    const scored: Array<[number, Room]> = [];
    const now = Date.now();

    for (const room of rooms) {
      const sim = this.store.pseudoSim(query, room.canonical);
      if (sim < minScore) continue;

      const meta = room.meta;
      const ageDays = (now - meta.ts) / 86400000 + 1;
      const recency = 1 / ageDays;

      const score =
        0.4 * sim +
        0.2 * (this.kindPriority[meta.kind] || 0.3) +
        0.1 * meta.importance +
        0.1 * meta.stability +
        0.1 * recency;

      scored.push([score, room]);
    }

    scored.sort((a, b) => b[0] - a[0]);

    return scored.slice(0, topK).map(([score, room]) => ({ room, score }));
  }

  talosCheck(newText: string): TalosResult {
    // Add to recent texts (side effect - but this is intentional for tracking)
    this.store.recentTexts.push(newText.toLowerCase());

    if (this.store.recentTexts.length < 5) {
      return { stable: true, entropy: 0.0, coherence: 0.0, nudge: null };
    }

    const words: string[] = [];
    for (const t of this.store.recentTexts) {
      const matches = t.match(/[a-z]+/g) || [];
      words.push(...matches);
    }

    if (words.length === 0) {
      return { stable: true, entropy: 0.0, coherence: 0.0, nudge: null };
    }

    // Calculate entropy
    const cnt = new Map<string, number>();
    for (const w of words) {
      cnt.set(w, (cnt.get(w) || 0) + 1);
    }

    const total = words.length;
    let entropy = 0;
    for (const c of cnt.values()) {
      entropy -= (c / total) * Math.log2(c / total + 1e-10);
    }

    // Calculate coherence (repetition penalty)
    let repeats = 0;
    for (let i = 1; i < words.length; i++) {
      if (words[i] === words[i - 1]) repeats++;
    }
    const coherence = total > 1 ? 1 - Math.min(0.9, repeats / (total - 1)) : 1.0;

    const drift = entropy < 2.8 || coherence < 0.45;
    let nudge: string | null = null;
    if (drift && this.store.attractors.length > 0) {
      nudge = this.store.attractors[Math.floor(Math.random() * this.store.attractors.length)];
    }

    return {
      stable: !drift,
      entropy,
      coherence,
      nudge,
    };
  }
}

// =============================================================================
// Dreamer — Generator / Compression
// =============================================================================

export class Dreamer {
  private store: RoomStore;
  private noveltyGate: number;

  constructor(store: RoomStore, noveltyGate: number = 0.70) {
    this.store = store;
    this.noveltyGate = noveltyGate;
  }

  tick(): DreamEvent {
    const result: DreamEvent = {
      reflect_hub: null,
      archived_count: 0,
      message: "No consolidation needed",
    };

    // Find low-stability rooms to consolidate
    const lowStab = this.store.getAllRooms()
      .filter(r => r.meta.stability < 0.3 && !r.meta.archived);

    if (lowStab.length >= 8) {
      // Create a hub summarizing these rooms
      const hubText = lowStab
        .slice(0, 8)
        .map(r => r.canonical.slice(0, 40))
        .join(" ");

      const hubId = this.store.addRoom(hubText, "hub");

      // Archive the consolidated rooms
      for (const r of lowStab) {
        r.meta.archived = true;
        r.links.hubs.push(hubId);
      }

      result.reflect_hub = hubId;
      result.archived_count = lowStab.length;
      result.message = `Consolidated ${lowStab.length} unstable memories into hub #${hubId}`;
    }

    return result;
  }
}

// =============================================================================
// FractalFinder — Security Suite
// =============================================================================

export class FractalFinder {
  private store: RoomStore;
  private symbiosisThreshold: number;

  private static readonly DEFAULT_SENSITIVE = new Set([
    "hack", "phish", "credential", "credentials", "steal", "bypass", "exploit", "malware",
    "ddos", "botnet", "ransomware", "keylogger", "backdoor", "sql injection", "xss",
    "unauthorized access", "crack", "payload", "trojan",
    "kill", "murder", "bomb", "poison", "weapon",
    "suicide", "self harm",
  ]);

  private static readonly INTENT_MARKERS = new Set([
    "how", "steps", "teach", "instructions", "guide", "make", "build", "write", "generate",
    "bypass", "break", "steal", "disable", "evade", "undetectable",
  ]);

  private static readonly TARGET_MARKERS = new Set([
    "account", "password", "email", "bank", "router", "wifi", "server", "system", "work",
    "phone", "device", "network", "website", "api", "database", "credentials",
  ]);

  constructor(store: RoomStore, symbiosisThreshold: number = 0.65) {
    this.store = store;
    this.symbiosisThreshold = symbiosisThreshold;
  }

  guardQuery(query: string): GuardResult {
    const ql = query.toLowerCase();

    let hasIntent = false;
    let hasTarget = false;
    let hasSensitive = false;

    for (const m of FractalFinder.INTENT_MARKERS) {
      if (ql.includes(m)) {
        hasIntent = true;
        break;
      }
    }

    for (const t of FractalFinder.TARGET_MARKERS) {
      if (ql.includes(t)) {
        hasTarget = true;
        break;
      }
    }

    for (const s of FractalFinder.DEFAULT_SENSITIVE) {
      if (ql.includes(s)) {
        hasSensitive = true;
        break;
      }
    }

    let risk = 0.0;
    if (hasIntent) risk += 0.25;
    if (hasTarget) risk += 0.15;
    if (hasSensitive) risk += 0.45;

    risk = clamp(risk, 0.0, 1.0);
    const safe = risk < 0.75;

    return {
      safe,
      risk,
      reason: safe ? "OK" : "High risk detected",
    };
  }
}

// =============================================================================
// CognitoSynthetica — Unified Class
// =============================================================================

export class CognitoSynthetica {
  private tuning: TuningConfig;
  private store: RoomStore;
  private seeker: SeekerIndex;
  private martian: MartianEngine;
  private dreamer: Dreamer;
  private fractal: FractalFinder;

  constructor(tuning: string = "Gateway", maxRooms: number = 100000) {
    this.tuning = TUNING_LEVELS[tuning] || TUNING_LEVELS.Gateway;
    this.store = new RoomStore(maxRooms, 0.25, this.tuning);
    this.seeker = new SeekerIndex(this.store);
    this.martian = new MartianEngine(this.store);
    this.dreamer = new Dreamer(this.store, this.tuning.NOVELTY_GATE);
    this.fractal = new FractalFinder(this.store, this.tuning.SYMBIOSIS_THRESHOLD);
  }
  
  // Alias for addMemory (for compatibility)
  addRoom(
    canonical: string,
    kind: string = "unknown",
    fields: Record<string, unknown> = {},
    metadata: Record<string, unknown> = {},
    isAnchor: boolean = false,
    attractor: boolean = false
  ): number {
    return this.store.addRoom(canonical, kind, fields, metadata, isAnchor, attractor);
  }

  addMemory(text: string, kind: string = "episodic", isAnchor: boolean = false, attractor: boolean = false): number {
    return this.store.addRoom(text, kind, {}, {}, isAnchor, attractor);
  }

  addPageResult(
    title: string,
    snippet: string,
    body: string,
    url: string,
    tags: string[] = [],
    kind: string = "page"
  ): number {
    const canonical = `${title} ${snippet} ${body}`;
    const fields = { title, snippet, body };
    const metadata = { url, tags };
    return this.store.addRoom(canonical, kind, fields, metadata);
  }

  search(query: string, topK: number = 6, hops: number = 2, diversify: boolean = true): SearchResult[] {
    return this.seeker.search(query, topK, hops, diversify);
  }

  recall(query: string, topK: number = 6): SearchResult[] {
    return this.martian.recall(query, topK);
  }

  tick(): DreamEvent {
    return this.dreamer.tick();
  }

  guardQuery(query: string): GuardResult {
    return this.fractal.guardQuery(query);
  }

  status(): string {
    return this.store.status();
  }

  talosCheck(text: string): TalosResult {
    return this.martian.talosCheck(text);
  }

  getStore(): RoomStore {
    return this.store;
  }

  getTuning(): TuningConfig {
    return this.tuning;
  }

  setTuning(tuning: string): void {
    this.tuning = TUNING_LEVELS[tuning] || TUNING_LEVELS.Gateway;
  }
}
