// =============================================================================
// PulseMemory — Geodesic Neural Strengthening System
// 
// Every 30 minutes, traverses ALL memory nodes in a single geodesic pathway,
// dreams insights for 30 seconds, and strengthens neural paths.
//
// Key formulas:
// - Lotus Cost: dist + λ_π·π + μ_risk·risk + singularity(σ)
// - Stability: sigmoid(-0.55 + 1.10·novelty + 1.70·nuance)
// - Path Strength: S(p) = Σ(1/lotus_cost) × traversal_count
// - Insight Quality: I = entropy(traversed_patterns) × avg_stability
// =============================================================================

import { RoomStore, Room, TuningConfig, TUNING_LEVELS } from './engine';

export interface PulseState {
  isActive: boolean;
  lastPulse: number | null;
  nextPulse: number | null;
  pulseCount: number;
  totalNodesVisited: number;
  totalInsights: number;
  totalPathsStrengthened: number;
}

export interface GeodesicPath {
  nodeIds: number[];
  totalCost: number;
  averageCost: number;
  coverage: number; // Percentage of nodes visited
  insights: string[];
  pathStrength: number;
}

export interface PulseResult {
  success: boolean;
  path: GeodesicPath | null;
  insights: string[];
  nodesVisited: number;
  pathsStrengthened: number;
  duration: number; // milliseconds
  error?: string;
}

export interface NeuralStrengthening {
  fromId: number;
  toId: number;
  previousWeight: number;
  newWeight: number;
  strengtheningFactor: number;
}

// Constants for the system
const PULSE_INTERVAL_MS = 30 * 60 * 1000; // 30 minutes
const DREAM_DURATION_MS = 30 * 1000; // 30 seconds for insight dreaming
const MIN_STRENGTHENING = 0.05;
const MAX_STRENGTHENING = 0.30;

class PulseMemory {
  private store: RoomStore;
  private tuning: TuningConfig;
  private state: PulseState;
  private pulseTimer: NodeJS.Timeout | null = null;
  private insightCallbacks: Array<(insights: string[]) => void> = [];
  
  // Neural strengthening tracking
  private recentStrengthening: NeuralStrengthening[] = [];
  private maxStrengtheningHistory: number = 100;
  
  // EPS for numerical stability
  private EPS: number = 1e-10;

  constructor(store: RoomStore, tuning: TuningConfig = TUNING_LEVELS.Gateway) {
    this.store = store;
    this.tuning = tuning;
    this.state = {
      isActive: false,
      lastPulse: null,
      nextPulse: null,
      pulseCount: 0,
      totalNodesVisited: 0,
      totalInsights: 0,
      totalPathsStrengthened: 0,
    };
  }

  // -------------------------------------------------------------------------
  // Core Algorithm: Geodesic Hamiltonian Path (Approximation)
  // -------------------------------------------------------------------------
  
  /**
   * Creates a geodesic path that visits ALL nodes exactly once (or as close as possible).
   * Uses a modified nearest-neighbor with Lotus Cost optimization.
   */
  createGeodesicPath(): GeodesicPath {
    const rooms = this.store.getAllRooms();
    const n = rooms.length;
    
    if (n === 0) {
      return {
        nodeIds: [],
        totalCost: 0,
        averageCost: 0,
        coverage: 0,
        insights: [],
        pathStrength: 0,
      };
    }

    if (n === 1) {
      return {
        nodeIds: [rooms[0].id],
        totalCost: 0,
        averageCost: 0,
        coverage: 100,
        insights: [`Single memory: ${rooms[0].canonical.slice(0, 50)}...`],
        pathStrength: rooms[0].meta.stability,
      };
    }

    // Use modified nearest-neighbor algorithm for Hamiltonian path approximation
    const visited = new Set<number>();
    const path: number[] = [];
    let totalCost = 0;
    
    // Start from highest importance node
    const sortedRooms = [...rooms].sort((a, b) => b.meta.importance - a.meta.importance);
    let current = sortedRooms[0].id;
    path.push(current);
    visited.add(current);

    // Greedy traversal with Lotus Cost optimization
    while (visited.size < n) {
      const currentRoom = this.store.roomById(current);
      if (!currentRoom) break;
      
      // Find nearest unvisited neighbor by Lotus Cost
      let bestNext: number | null = null;
      let bestCost = Infinity;
      
      for (const room of rooms) {
        if (visited.has(room.id)) continue;
        
        const cost = this.calculateLotusCost(currentRoom, room);
        if (cost < bestCost) {
          bestCost = cost;
          bestNext = room.id;
        }
      }
      
      if (bestNext === null) break;
      
      totalCost += bestCost;
      path.push(bestNext);
      visited.add(bestNext);
      current = bestNext;
    }

    // Calculate metrics
    const coverage = (visited.size / n) * 100;
    const averageCost = path.length > 1 ? totalCost / (path.length - 1) : 0;
    
    // Generate insights from the traversal
    const insights = this.generatePathInsights(path);
    
    // Calculate path strength
    const pathStrength = this.calculatePathStrength(path);

    return {
      nodeIds: path,
      totalCost,
      averageCost,
      coverage,
      insights,
      pathStrength,
    };
  }

  /**
   * Calculate Lotus Cost between two rooms.
   * Formula: dist + λ_π·(π_a + π_b)/2 + μ_risk·max(risk_a, risk_b) + singularity
   */
  private calculateLotusCost(roomA: Room, roomB: Room): number {
    // Semantic distance (1 - similarity)
    const sim = this.store.pseudoSim(roomA.canonical, roomB.canonical);
    const dist = 1.0 - sim;
    
    // Pi (informational potential) term
    const pi = 0.5 * (roomA.meta.pi + roomB.meta.pi);
    const piTerm = this.tuning.LAMBDA_PI * pi;
    
    // Risk term
    const risk = Math.max(roomA.meta.risk, roomB.meta.risk);
    const riskTerm = this.tuning.MU_RISK * risk;
    
    // Singularity term (high-risk penalty)
    const sing = risk > this.tuning.SINGULARITY_GATE
      ? 1 / (1 - risk + this.EPS)
      : 0.0;
    
    return dist + piTerm + riskTerm + sing;
  }

  // -------------------------------------------------------------------------
  // Neural Strengthening (Not Deletion!)
  // -------------------------------------------------------------------------

  /**
   * Strengthen neural pathways along the geodesic path.
   * Strength is increased, never decreased. No pruning!
   */
  strengthenPaths(path: number[]): number {
    let strengthened = 0;
    const graph = this.store.graph;
    
    this.recentStrengthening = [];
    
    for (let i = 0; i < path.length - 1; i++) {
      const fromId = path[i];
      const toId = path[i + 1];
      
      // Get current edge weight
      const neighbors = graph.get(fromId);
      if (!neighbors) continue;
      
      const currentWeight = neighbors.get(toId);
      if (currentWeight === undefined) continue;
      
      // Calculate strengthening factor based on room properties
      const fromRoom = this.store.roomById(fromId);
      const toRoom = this.store.roomById(toId);
      if (!fromRoom || !toRoom) continue;
      
      // Strengthening formula: ΔS = MIN_STR + (MAX_STR - MIN_STR) × (stability_a + stability_b) / 2
      const avgStability = (fromRoom.meta.stability + toRoom.meta.stability) / 2;
      const avgImportance = (fromRoom.meta.importance + toRoom.meta.importance) / 2;
      const strengtheningFactor = MIN_STRENGTHENING + 
        (MAX_STRENGTHENING - MIN_STRENGTHENING) * (avgStability * 0.7 + avgImportance * 0.3);
      
      // Apply strengthening: lower cost = stronger connection
      const newWeight = currentWeight * (1 - strengtheningFactor);
      
      // Update bidirectional edges
      neighbors.set(toId, newWeight);
      const reverseNeighbors = graph.get(toId);
      if (reverseNeighbors) {
        reverseNeighbors.set(fromId, newWeight);
      }
      
      // Track strengthening
      this.recentStrengthening.push({
        fromId,
        toId,
        previousWeight: currentWeight,
        newWeight,
        strengtheningFactor,
      });
      
      strengthened++;
    }
    
    // Trim history
    if (this.recentStrengthening.length > this.maxStrengtheningHistory) {
      this.recentStrengthening = this.recentStrengthening.slice(-this.maxStrengtheningHistory);
    }
    
    return strengthened;
  }

  // -------------------------------------------------------------------------
  // Insight Generation
  // -------------------------------------------------------------------------

  /**
   * Generate insights from the geodesic path traversal.
   * Analyzes patterns, themes, and connections.
   */
  private generatePathInsights(path: number[]): string[] {
    const insights: string[] = [];
    
    if (path.length < 3) {
      return insights;
    }
    
    // Get all rooms in path
    const rooms = path
      .map(id => this.store.roomById(id))
      .filter((r): r is Room => r !== undefined);
    
    // 1. Theme clustering insight
    const kindCounts: Record<string, number> = {};
    for (const room of rooms) {
      kindCounts[room.meta.kind] = (kindCounts[room.meta.kind] || 0) + 1;
    }
    const dominantKind = Object.entries(kindCounts)
      .sort((a, b) => b[1] - a[1])[0];
    if (dominantKind && dominantKind[1] > path.length * 0.4) {
      insights.push(`Memory landscape dominated by ${dominantKind[0]} memories (${dominantKind[1]} nodes)`);
    }
    
    // 2. Stability gradient insight
    const stabilities = rooms.map(r => r.meta.stability);
    const avgStability = stabilities.reduce((a, b) => a + b, 0) / stabilities.length;
    const highStability = stabilities.filter(s => s > 0.8).length;
    const lowStability = stabilities.filter(s => s < 0.3).length;
    
    if (highStability > path.length * 0.3) {
      insights.push(`Strong memory core: ${highStability} highly stable memories`);
    }
    if (lowStability > path.length * 0.2) {
      insights.push(`Emerging patterns: ${lowStability} memories in flux, ready for consolidation`);
    }
    
    // 3. Connection insight (consecutive pairs with similar content)
    let strongConnections = 0;
    for (let i = 0; i < rooms.length - 1; i++) {
      const sim = this.store.pseudoSim(rooms[i].canonical, rooms[i + 1].canonical);
      if (sim > 0.5) strongConnections++;
    }
    if (strongConnections > path.length * 0.2) {
      insights.push(`Dense semantic clusters: ${strongConnections} strong sequential connections`);
    }
    
    // 4. Temporal insight
    const timestamps = rooms.map(r => r.meta.ts);
    const oldest = Math.min(...timestamps);
    const newest = Math.max(...timestamps);
    const spanHours = (newest - oldest) / (1000 * 60 * 60);
    
    if (spanHours > 24) {
      insights.push(`Memory spans ${spanHours.toFixed(1)} hours of experiences`);
    } else if (spanHours > 1) {
      insights.push(`Recent memory cluster: ${spanHours.toFixed(1)} hours of activity`);
    }
    
    // 5. Novelty distribution insight
    const novelties = rooms.map(r => r.meta.novelty);
    const avgNovelty = novelties.reduce((a, b) => a + b, 0) / novelties.length;
    const highNovelty = novelties.filter(n => n > 0.7).length;
    
    if (avgNovelty > 0.6) {
      insights.push(`High exploration phase: avg novelty ${(avgNovelty * 100).toFixed(0)}%`);
    } else if (avgNovelty < 0.3) {
      insights.push(`Consolidation phase: deepening existing knowledge`);
    }
    
    // 6. Semantic keyword insight
    const allWords = rooms.flatMap(r => this.store.tokens(r.canonical));
    const wordFreq: Record<string, number> = {};
    for (const word of allWords) {
      wordFreq[word] = (wordFreq[word] || 0) + 1;
    }
    const topWords = Object.entries(wordFreq)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([w]) => w);
    
    if (topWords.length > 0) {
      insights.push(`Key themes: ${topWords.join(', ')}`);
    }
    
    return insights;
  }

  /**
   * Calculate the strength of a path based on node properties.
   */
  private calculatePathStrength(path: number[]): number {
    if (path.length === 0) return 0;
    
    let totalStrength = 0;
    for (const id of path) {
      const room = this.store.roomById(id);
      if (room) {
        // Strength = stability × importance × (1 + novelty)
        const strength = room.meta.stability * room.meta.importance * (1 + room.meta.novelty * 0.5);
        totalStrength += strength;
      }
    }
    
    return totalStrength / path.length;
  }

  // -------------------------------------------------------------------------
  // Pulse Execution
  // -------------------------------------------------------------------------

  /**
   * Execute a single pulse: geodesic traversal + dream + strengthen.
   */
  async pulse(): Promise<PulseResult> {
    const startTime = Date.now();
    
    try {
      // Step 1: Create geodesic path through all nodes
      const path = this.createGeodesicPath();
      
      // Step 2: Dream for 30 seconds (process insights)
      const dreamInsights = await this.dreamInsights(path);
      path.insights = [...path.insights, ...dreamInsights];
      
      // Step 3: Strengthen neural paths (no deletion!)
      const pathsStrengthened = this.strengthenPaths(path.nodeIds);
      
      // Step 4: Store insights as new memories
      for (const insight of path.insights) {
        this.store.addRoom(
          `[PULSE INSIGHT] ${insight}`,
          'semantic',
          {},
          { 
            kind: 'semantic', 
            pulse_generated: true,
            stability: 0.9,
          },
          false,
          false
        );
      }
      
      // Update state
      this.state.lastPulse = startTime;
      this.state.pulseCount++;
      this.state.totalNodesVisited += path.nodeIds.length;
      this.state.totalInsights += path.insights.length;
      this.state.totalPathsStrengthened += pathsStrengthened;
      
      const duration = Date.now() - startTime;
      
      return {
        success: true,
        path,
        insights: path.insights,
        nodesVisited: path.nodeIds.length,
        pathsStrengthened,
        duration,
      };
    } catch (error) {
      return {
        success: false,
        path: null,
        insights: [],
        nodesVisited: 0,
        pathsStrengthened: 0,
        duration: Date.now() - startTime,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Dream insights - a 30-second deep processing phase.
   * Uses entropy analysis and pattern recognition.
   */
  private async dreamInsights(path: GeodesicPath): Promise<string[]> {
    const insights: string[] = [];
    
    // Simulate 30 seconds of dreaming with progressive insight generation
    // In practice, this happens quickly but simulates the "dreaming" state
    const dreamPhases = 5;
    const phaseTime = DREAM_DURATION_MS / dreamPhases;
    
    for (let phase = 0; phase < dreamPhases; phase++) {
      // Phase 1: Entropy analysis
      if (phase === 0) {
        const entropyInsight = this.analyzeEntropy(path);
        if (entropyInsight) insights.push(entropyInsight);
      }
      
      // Phase 2: Pattern clustering
      if (phase === 1) {
        const patternInsight = this.analyzePatterns(path);
        if (patternInsight) insights.push(patternInsight);
      }
      
      // Phase 3: Temporal coherence
      if (phase === 2) {
        const temporalInsight = this.analyzeTemporalCoherence(path);
        if (temporalInsight) insights.push(temporalInsight);
      }
      
      // Phase 4: Semantic bridges
      if (phase === 3) {
        const bridgeInsight = this.findSemanticBridges(path);
        if (bridgeInsight) insights.push(bridgeInsight);
      }
      
      // Phase 5: Growth recommendations
      if (phase === 4) {
        const growthInsight = this.analyzeGrowth(path);
        if (growthInsight) insights.push(growthInsight);
      }
      
      // Small delay to simulate dreaming (in production, this would be 6 seconds per phase)
      await new Promise(resolve => setTimeout(resolve, Math.min(100, phaseTime)));
    }
    
    return insights;
  }

  // -------------------------------------------------------------------------
  // Dream Analysis Methods
  // -------------------------------------------------------------------------

  private analyzeEntropy(path: GeodesicPath): string | null {
    const rooms = path.nodeIds
      .map(id => this.store.roomById(id))
      .filter((r): r is Room => r !== undefined);
    
    if (rooms.length < 5) return null;
    
    // Calculate entropy of kinds
    const kindCounts: Record<string, number> = {};
    for (const room of rooms) {
      kindCounts[room.meta.kind] = (kindCounts[room.meta.kind] || 0) + 1;
    }
    
    const total = rooms.length;
    let entropy = 0;
    for (const count of Object.values(kindCounts)) {
      const p = count / total;
      entropy -= p * Math.log2(p + this.EPS);
    }
    
    // Max entropy for 5 kinds is log2(5) ≈ 2.32
    const normalizedEntropy = entropy / Math.log2(Object.keys(kindCounts).length || 5);
    
    if (normalizedEntropy > 0.8) {
      return `High memory diversity (entropy: ${(normalizedEntropy * 100).toFixed(0)}%) - well-balanced knowledge`;
    } else if (normalizedEntropy < 0.4) {
      return `Focused memory state (entropy: ${(normalizedEntropy * 100).toFixed(0)}%) - specialized knowledge`;
    }
    
    return null;
  }

  private analyzePatterns(path: GeodesicPath): string | null {
    const rooms = path.nodeIds
      .map(id => this.store.roomById(id))
      .filter((r): r is Room => r !== undefined);
    
    if (rooms.length < 4) return null;
    
    // Find repeating patterns in consecutive stability values
    const stabilities = rooms.map(r => r.meta.stability.toFixed(1));
    const stabilityPattern = stabilities.join('');
    
    // Check for oscillation (high-low-high)
    let oscillations = 0;
    for (let i = 2; i < stabilities.length; i++) {
      const prev = parseFloat(stabilities[i - 2]);
      const curr = parseFloat(stabilities[i - 1]);
      const next = parseFloat(stabilities[i]);
      if ((prev > curr && next > curr) || (prev < curr && next < curr)) {
        oscillations++;
      }
    }
    
    if (oscillations > rooms.length * 0.3) {
      return `Oscillating memory pattern detected (${oscillations} transitions) - dynamic processing`;
    }
    
    return null;
  }

  private analyzeTemporalCoherence(path: GeodesicPath): string | null {
    const rooms = path.nodeIds
      .map(id => this.store.roomById(id))
      .filter((r): r is Room => r !== undefined);
    
    if (rooms.length < 3) return null;
    
    // Check if path follows temporal order
    let inOrder = 0;
    let reverseOrder = 0;
    
    for (let i = 1; i < rooms.length; i++) {
      if (rooms[i].meta.ts > rooms[i - 1].meta.ts) inOrder++;
      else reverseOrder++;
    }
    
    const temporalRatio = inOrder / (rooms.length - 1);
    
    if (temporalRatio > 0.7) {
      return `Strong temporal coherence (${(temporalRatio * 100).toFixed(0)}%) - sequential memory flow`;
    } else if (temporalRatio < 0.3) {
      return `Reverse temporal traversal - accessing older memories for consolidation`;
    }
    
    return null;
  }

  private findSemanticBridges(path: GeodesicPath): string | null {
    const rooms = path.nodeIds
      .map(id => this.store.roomById(id))
      .filter((r): r is Room => r !== undefined);
    
    if (rooms.length < 4) return null;
    
    // Find "bridge" nodes that connect disparate clusters
    // A bridge has high similarity to both previous and next nodes
    let bridges = 0;
    
    for (let i = 1; i < rooms.length - 1; i++) {
      const prevSim = this.store.pseudoSim(rooms[i - 1].canonical, rooms[i].canonical);
      const nextSim = this.store.pseudoSim(rooms[i].canonical, rooms[i + 1].canonical);
      
      // Bridge: high similarity to both neighbors but neighbors are dissimilar to each other
      const neighborSim = this.store.pseudoSim(rooms[i - 1].canonical, rooms[i + 1].canonical);
      
      if (prevSim > 0.3 && nextSim > 0.3 && neighborSim < 0.2) {
        bridges++;
      }
    }
    
    if (bridges > 0) {
      return `Found ${bridges} semantic bridge(s) connecting disparate memory clusters`;
    }
    
    return null;
  }

  private analyzeGrowth(path: GeodesicPath): string | null {
    const rooms = path.nodeIds
      .map(id => this.store.roomById(id))
      .filter((r): r is Room => r !== undefined);
    
    if (rooms.length < 5) return null;
    
    // Analyze growth potential
    const lowStability = rooms.filter(r => r.meta.stability < 0.4);
    const highNovelty = rooms.filter(r => r.meta.novelty > 0.6);
    
    if (lowStability.length > rooms.length * 0.3 && highNovelty.length > rooms.length * 0.2) {
      return `High growth potential: ${lowStability.length} memories ready for strengthening, ${highNovelty.length} novel experiences`;
    }
    
    if (lowStability.length < rooms.length * 0.1) {
      return `Memory system stable: ${rooms.length - lowStability.length} memories consolidated`;
    }
    
    return null;
  }

  // -------------------------------------------------------------------------
  // Auto-Pulse System
  // -------------------------------------------------------------------------

  /**
   * Start automatic pulsing every 30 minutes.
   */
  startAutoPulse(): void {
    if (this.pulseTimer) {
      clearInterval(this.pulseTimer);
    }
    
    this.state.isActive = true;
    this.state.nextPulse = Date.now() + PULSE_INTERVAL_MS;
    
    this.pulseTimer = setInterval(async () => {
      console.log('[PulseMemory] Executing scheduled pulse...');
      const result = await this.pulse();
      
      if (result.success) {
        console.log(`[PulseMemory] Pulse complete: ${result.nodesVisited} nodes, ${result.insights.length} insights`);
        
        // Notify callbacks
        for (const callback of this.insightCallbacks) {
          callback(result.insights);
        }
      }
      
      this.state.nextPulse = Date.now() + PULSE_INTERVAL_MS;
    }, PULSE_INTERVAL_MS);
    
    console.log(`[PulseMemory] Auto-pulse started (interval: ${PULSE_INTERVAL_MS / 60000} minutes)`);
  }

  /**
   * Stop automatic pulsing.
   */
  stopAutoPulse(): void {
    if (this.pulseTimer) {
      clearInterval(this.pulseTimer);
      this.pulseTimer = null;
    }
    this.state.isActive = false;
    this.state.nextPulse = null;
    console.log('[PulseMemory] Auto-pulse stopped');
  }

  /**
   * Register callback for insight notifications.
   */
  onInsight(callback: (insights: string[]) => void): void {
    this.insightCallbacks.push(callback);
  }

  // -------------------------------------------------------------------------
  // State and Status
  // -------------------------------------------------------------------------

  getState(): PulseState {
    return { ...this.state };
  }

  getRecentStrengthening(): NeuralStrengthening[] {
    return [...this.recentStrengthening];
  }

  getStatus(): {
    state: PulseState;
    intervalMinutes: number;
    dreamDurationSeconds: number;
  } {
    return {
      state: this.getState(),
      intervalMinutes: PULSE_INTERVAL_MS / 60000,
      dreamDurationSeconds: DREAM_DURATION_MS / 1000,
    };
  }

  /**
   * Update tuning configuration.
   */
  updateTuning(tuning: TuningConfig): void {
    this.tuning = tuning;
  }

  /**
   * Reset pulse state.
   */
  reset(): void {
    this.stopAutoPulse();
    this.state = {
      isActive: false,
      lastPulse: null,
      nextPulse: null,
      pulseCount: 0,
      totalNodesVisited: 0,
      totalInsights: 0,
      totalPathsStrengthened: 0,
    };
    this.recentStrengthening = [];
    this.insightCallbacks = [];
  }
}

// Singleton instance management
let pulseMemoryInstance: PulseMemory | null = null;

export function getPulseMemory(store?: RoomStore, tuning?: TuningConfig): PulseMemory {
  if (!pulseMemoryInstance && store) {
    pulseMemoryInstance = new PulseMemory(store, tuning);
  } else if (!pulseMemoryInstance) {
    // Create a default instance with an empty store if needed
    // This shouldn't happen in normal use, but provides a fallback
    throw new Error('PulseMemory not initialized. Call getPulseMemory with store first.');
  }
  // Update tuning if provided
  if (tuning && pulseMemoryInstance) {
    pulseMemoryInstance.updateTuning(tuning);
  }
  return pulseMemoryInstance;
}

export function initPulseMemory(store: RoomStore, tuning?: TuningConfig): PulseMemory {
  pulseMemoryInstance = new PulseMemory(store, tuning);
  return pulseMemoryInstance;
}

export default PulseMemory;
