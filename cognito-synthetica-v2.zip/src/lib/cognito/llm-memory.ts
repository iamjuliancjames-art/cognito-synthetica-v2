// =============================================================================
// LLM Memory Accumulator - Collects memories for training/reference
// This module accumulates all conversations, imports, dreams into a format
// suitable for building a reference LLM that grows over time.
// =============================================================================

export interface TrainingExample {
  id: string;
  timestamp: number;
  type: 'conversation' | 'import' | 'dream' | 'reflection' | 'commitment';
  input: string;
  output: string;
  metadata: {
    source: string;
    importance: number;
    tags: string[];
    memoryId?: number;
  };
}

export interface LLMMemoryState {
  version: string;
  createdAt: number;
  lastUpdated: number;
  totalExamples: number;
  totalTokens: number;
  examples: TrainingExample[];
  knowledgeBase: KnowledgeEntry[];
  metabolismCount: number;
  lastMetabolism: number | null;
}

export interface KnowledgeEntry {
  id: string;
  concept: string;
  summary: string;
  relatedMemories: number[];
  confidence: number;
  lastAccessed: number;
  accessCount: number;
}

export interface MetabolismResult {
  processed: number;
  newKnowledge: number;
  consolidated: number;
  archived: number;
  insights: string[];
}

class LLMMemoryAccumulator {
  private state: LLMMemoryState;
  private pendingExamples: TrainingExample[] = [];
  private maxExamples: number = 10000;
  private maxKnowledge: number = 1000;

  constructor() {
    this.state = {
      version: '1.0.0',
      createdAt: Date.now(),
      lastUpdated: Date.now(),
      totalExamples: 0,
      totalTokens: 0,
      examples: [],
      knowledgeBase: [],
      metabolismCount: 0,
      lastMetabolism: null,
    };
  }

  // Add a conversation as training data
  addConversation(
    userMessage: string,
    assistantResponse: string,
    memoriesUsed: number = 0,
    memoriesStored: number = 0
  ): TrainingExample {
    const example: TrainingExample = {
      id: `conv-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      timestamp: Date.now(),
      type: 'conversation',
      input: userMessage,
      output: assistantResponse,
      metadata: {
        source: 'chat',
        importance: this.calculateImportance(userMessage, assistantResponse),
        tags: this.extractTags(userMessage, assistantResponse),
      },
    };

    this.pendingExamples.push(example);
    this.state.totalExamples++;
    this.state.lastUpdated = Date.now();

    // Keep within limits
    if (this.state.examples.length < this.maxExamples) {
      this.state.examples.push(example);
    }

    return example;
  }

  // Add an import as training data
  addImport(
    filename: string,
    content: string,
    summary: string,
    memoryCount: number
  ): TrainingExample {
    const example: TrainingExample = {
      id: `import-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      timestamp: Date.now(),
      type: 'import',
      input: `Import document: ${filename}`,
      output: summary,
      metadata: {
        source: 'file_upload',
        importance: 0.8,
        tags: ['document', 'import', filename],
      },
    };

    this.pendingExamples.push(example);
    this.state.totalExamples++;
    this.state.lastUpdated = Date.now();

    if (this.state.examples.length < this.maxExamples) {
      this.state.examples.push(example);
    }

    return example;
  }

  // Add a dream event as training data
  addDream(
    dreamMessage: string,
    archivedCount: number,
    hubId: number | null
  ): TrainingExample {
    const example: TrainingExample = {
      id: `dream-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      timestamp: Date.now(),
      type: 'dream',
      input: 'Memory consolidation cycle',
      output: dreamMessage,
      metadata: {
        source: 'dream_cycle',
        importance: 0.6,
        tags: ['dream', 'consolidation', 'memory'],
        memoryId: hubId ?? undefined,
      },
    };

    this.pendingExamples.push(example);
    this.state.totalExamples++;
    this.state.lastUpdated = Date.now();

    if (this.state.examples.length < this.maxExamples) {
      this.state.examples.push(example);
    }

    return example;
  }

  // Add a reflection/self-analysis as training data
  addReflection(
    query: string,
    analysis: string,
    memoryStats: Record<string, unknown>
  ): TrainingExample {
    const example: TrainingExample = {
      id: `reflect-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      timestamp: Date.now(),
      type: 'reflection',
      input: query,
      output: analysis,
      metadata: {
        source: 'meta_cognitive',
        importance: 0.9,
        tags: ['reflection', 'meta', 'self-analysis'],
      },
    };

    this.pendingExamples.push(example);
    this.state.totalExamples++;
    this.state.lastUpdated = Date.now();

    if (this.state.examples.length < this.maxExamples) {
      this.state.examples.push(example);
    }

    return example;
  }

  // Add a commitment as training data
  addCommitment(
    commitment: string,
    context: string
  ): TrainingExample {
    const example: TrainingExample = {
      id: `commit-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      timestamp: Date.now(),
      type: 'commitment',
      input: context,
      output: commitment,
      metadata: {
        source: 'commitment_tracking',
        importance: 1.0,
        tags: ['commitment', 'promise', 'important'],
      },
    };

    this.pendingExamples.push(example);
    this.state.totalExamples++;
    this.state.lastUpdated = Date.now();

    if (this.state.examples.length < this.maxExamples) {
      this.state.examples.push(example);
    }

    return example;
  }

  // Metabolize pending examples into knowledge base
  metabolize(): MetabolismResult {
    const result: MetabolismResult = {
      processed: 0,
      newKnowledge: 0,
      consolidated: 0,
      archived: 0,
      insights: [],
    };

    if (this.pendingExamples.length === 0) {
      return result;
    }

    // Process pending examples
    const toProcess = [...this.pendingExamples];
    this.pendingExamples = [];

    for (const example of toProcess) {
      result.processed++;

      // Extract knowledge from high-importance examples
      if (example.metadata.importance >= 0.7) {
        const entry = this.extractKnowledge(example);
        if (entry) {
          // Check if similar concept exists
          const existing = this.findSimilarKnowledge(entry.concept);
          if (existing) {
            // Consolidate with existing
            existing.relatedMemories.push(...entry.relatedMemories);
            existing.confidence = Math.min(1.0, existing.confidence + 0.1);
            existing.lastAccessed = Date.now();
            result.consolidated++;
          } else if (this.state.knowledgeBase.length < this.maxKnowledge) {
            this.state.knowledgeBase.push(entry);
            result.newKnowledge++;
          }
        }
      }
    }

    // Generate insights from patterns
    result.insights = this.generateInsights();

    // Archive old, low-importance examples
    const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000; // 7 days
    const beforeArchive = this.state.examples.length;
    this.state.examples = this.state.examples.filter(
      e => e.metadata.importance >= 0.5 || e.timestamp >= cutoff
    );
    result.archived = beforeArchive - this.state.examples.length;

    // Update state
    this.state.metabolismCount++;
    this.state.lastMetabolism = Date.now();
    this.state.lastUpdated = Date.now();

    // Estimate tokens
    this.state.totalTokens = this.estimateTokens();

    return result;
  }

  // Extract knowledge from a training example
  private extractKnowledge(example: TrainingExample): KnowledgeEntry | null {
    const concept = this.extractConcept(example);
    if (!concept) return null;

    return {
      id: `know-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      concept,
      summary: example.output.slice(0, 500),
      relatedMemories: example.metadata.memoryId ? [example.metadata.memoryId] : [],
      confidence: example.metadata.importance,
      lastAccessed: Date.now(),
      accessCount: 1,
    };
  }

  // Extract main concept from example
  private extractConcept(example: TrainingExample): string | null {
    const text = example.input + ' ' + example.output;
    
    // Extract key phrases
    const patterns = [
      /user(?:'s)? (\w+) (?:is|are|was|were|likes|loves|wants|needs)/i,
      /(?:the|a) (\w+(?:\s+\w+)?) (?:is|are|was|were)/i,
      /(?:learned|remembered|discovered) (?:that|about) (.+?)(?:\.|$)/i,
      /import(?:ed)? document[:\s]+(.+?)(?:\.|$)/i,
      /commit(?:ment)?[:\s]+(.+?)(?:\.|$)/i,
    ];

    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match) {
        return match[1]?.trim() || match[0].trim();
      }
    }

    // Fallback: use first significant words
    const words = text.toLowerCase().match(/\b[a-z]{4,}\b/g);
    if (words && words.length >= 2) {
      return words.slice(0, 3).join(' ');
    }

    return null;
  }

  // Find similar knowledge in the base
  private findSimilarKnowledge(concept: string): KnowledgeEntry | null {
    const conceptLower = concept.toLowerCase();
    
    for (const entry of this.state.knowledgeBase) {
      if (entry.concept.toLowerCase().includes(conceptLower) ||
          conceptLower.includes(entry.concept.toLowerCase())) {
        return entry;
      }
    }

    return null;
  }

  // Generate insights from accumulated knowledge
  private generateInsights(): string[] {
    const insights: string[] = [];

    // Analyze conversation patterns
    const conversations = this.state.examples.filter(e => e.type === 'conversation');
    if (conversations.length >= 10) {
      const avgImportance = conversations.reduce((sum, e) => sum + e.metadata.importance, 0) / conversations.length;
      insights.push(`Average conversation importance: ${(avgImportance * 100).toFixed(1)}%`);
    }

    // Analyze knowledge coverage
    if (this.state.knowledgeBase.length >= 5) {
      const highConfidence = this.state.knowledgeBase.filter(k => k.confidence >= 0.8).length;
      insights.push(`${highConfidence} high-confidence knowledge entries`);
    }

    // Suggest improvements
    const types = new Set(this.state.examples.map(e => e.type));
    if (!types.has('reflection')) {
      insights.push('Consider more meta-cognitive reflection for better self-awareness');
    }

    return insights;
  }

  // Calculate importance score
  private calculateImportance(input: string, output: string): number {
    let score = 0.5;

    // Check for important keywords
    const importantPatterns = [
      { pattern: /important|critical|essential|key|crucial/i, boost: 0.2 },
      { pattern: /remember|don'?t forget|keep in mind/i, boost: 0.15 },
      { pattern: /my name is|i am|i work|i live/i, boost: 0.1 },
      { pattern: /goal|objective|target|aim/i, boost: 0.1 },
      { pattern: /\?/g, boost: 0.05 }, // Questions are slightly more important
    ];

    for (const { pattern, boost } of importantPatterns) {
      if (pattern.test(input) || pattern.test(output)) {
        score += boost;
      }
    }

    // Length bonus (more content = potentially more important)
    const totalLength = input.length + output.length;
    if (totalLength > 500) score += 0.1;
    if (totalLength > 1000) score += 0.1;

    return Math.min(1.0, score);
  }

  // Extract tags from content
  private extractTags(input: string, output: string): string[] {
    const tags: string[] = [];
    const text = input + ' ' + output;

    const tagPatterns = [
      { pattern: /name[:\s]+(\w+)/i, tag: (m: RegExpMatchArray) => `person:${m[1]}` },
      { pattern: /work(?:s|ing)?(?:\s+as|ed)?[:\s]+(.+?)(?:\.|,|$)/i, tag: (m: RegExpMatchArray) => `work:${m[1]?.trim()}` },
      { pattern: /live[s]?[:\s]+in[:\s]+(.+?)(?:\.|,|$)/i, tag: (m: RegExpMatchArray) => `location:${m[1]?.trim()}` },
      { pattern: /(?:like|love)s?[:\s]+(.+?)(?:\.|,|$)/i, tag: (m: RegExpMatchArray) => `interest:${m[1]?.trim()}` },
    ];

    for (const { pattern, tag } of tagPatterns) {
      const match = text.match(pattern);
      if (match) {
        tags.push(tag(match));
      }
    }

    return tags;
  }

  // Estimate total tokens
  private estimateTokens(): number {
    let total = 0;
    for (const example of this.state.examples) {
      // Rough estimate: ~4 chars per token
      total += Math.ceil((example.input.length + example.output.length) / 4);
    }
    for (const entry of this.state.knowledgeBase) {
      total += Math.ceil((entry.concept.length + entry.summary.length) / 4);
    }
    return total;
  }

  // Get current state
  getState(): LLMMemoryState {
    return { ...this.state };
  }

  // Get training data in JSONL format
  getTrainingDataJSONL(): string {
    return this.state.examples
      .map(e => JSON.stringify({
        messages: [
          { role: 'user', content: e.input },
          { role: 'assistant', content: e.output },
        ],
        metadata: e.metadata,
      }))
      .join('\n');
  }

  // Get knowledge base for reference
  getKnowledgeBase(): KnowledgeEntry[] {
    return [...this.state.knowledgeBase];
  }

  // Search knowledge base
  searchKnowledge(query: string, limit: number = 5): KnowledgeEntry[] {
    const queryLower = query.toLowerCase();
    
    return this.state.knowledgeBase
      .filter(entry => 
        entry.concept.toLowerCase().includes(queryLower) ||
        entry.summary.toLowerCase().includes(queryLower)
      )
      .sort((a, b) => {
        // Sort by relevance (confidence * recency)
        const scoreA = a.confidence * (1 + a.accessCount * 0.1);
        const scoreB = b.confidence * (1 + b.accessCount * 0.1);
        return scoreB - scoreA;
      })
      .slice(0, limit);
  }

  // Get pending count
  getPendingCount(): number {
    return this.pendingExamples.length;
  }

  // Export state for persistence
  export(): string {
    return JSON.stringify(this.state, null, 2);
  }

  // Import state from persistence
  import(data: string): void {
    try {
      const parsed = JSON.parse(data);
      this.state = {
        ...this.state,
        ...parsed,
        lastUpdated: Date.now(),
      };
    } catch (error) {
      console.error('Failed to import LLM memory state:', error);
    }
  }

  // Reset to initial state
  reset(): void {
    this.state = {
      version: '1.0.0',
      createdAt: Date.now(),
      lastUpdated: Date.now(),
      totalExamples: 0,
      totalTokens: 0,
      examples: [],
      knowledgeBase: [],
      metabolismCount: 0,
      lastMetabolism: null,
    };
    this.pendingExamples = [];
  }
}

// Singleton instance
let accumulatorInstance: LLMMemoryAccumulator | null = null;

export function getLLMMemory(): LLMMemoryAccumulator {
  if (!accumulatorInstance) {
    accumulatorInstance = new LLMMemoryAccumulator();
  }
  return accumulatorInstance;
}

export default LLMMemoryAccumulator;
