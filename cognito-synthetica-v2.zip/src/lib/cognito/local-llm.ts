// =============================================================================
// Local LLM Client - Support for Ollama, LM Studio, and OpenAI-compatible APIs
// Allows running LLMs locally without cloud API calls
// =============================================================================

export interface LocalLLMConfig {
  type: 'ollama' | 'openai-compatible' | 'llama-cpp';
  baseUrl: string;
  model: string;
  apiKey?: string;
  timeout?: number;
}

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface ChatResponse {
  content: string;
  model: string;
  usage?: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export interface ModelInfo {
  name: string;
  size?: string;
  modified_at?: string;
}

// Default configurations for different local LLM providers
const DEFAULT_CONFIGS = {
  ollama: {
    baseUrl: 'http://localhost:11434',
    model: 'llama3.2',
  },
  'openai-compatible': {
    baseUrl: 'http://localhost:1234', // LM Studio default
    model: 'local-model',
  },
  'llama-cpp': {
    baseUrl: 'http://localhost:8080',
    model: 'local',
  },
};

class LocalLLMClient {
  private config: LocalLLMConfig;

  constructor(config: Partial<LocalLLMConfig> = {}) {
    const type = config.type || 'openai-compatible';
    const defaults = DEFAULT_CONFIGS[type];

    this.config = {
      type,
      baseUrl: config.baseUrl || defaults.baseUrl,
      model: config.model || defaults.model,
      apiKey: config.apiKey,
      timeout: config.timeout || 60000,
    };
  }

  getConfig(): LocalLLMConfig {
    return { ...this.config };
  }

  /**
   * Check if the local LLM server is available
   */
  async isAvailable(): Promise<boolean> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);

      let healthUrl: string;
      if (this.config.type === 'ollama') {
        healthUrl = `${this.config.baseUrl}/api/tags`;
      } else {
        // OpenAI-compatible (LM Studio, etc.)
        healthUrl = `${this.config.baseUrl}/v1/models`;
      }

      const response = await fetch(healthUrl, {
        method: 'GET',
        signal: controller.signal,
        headers: this.getHeaders(),
      });

      clearTimeout(timeoutId);
      return response.ok;
    } catch {
      return false;
    }
  }

  /**
   * List available models
   */
  async listModels(): Promise<ModelInfo[]> {
    try {
      if (this.config.type === 'ollama') {
        const response = await fetch(`${this.config.baseUrl}/api/tags`);
        if (!response.ok) return [];

        const data = await response.json();
        return (data.models || []).map((m: { name: string; size?: number; modified_at?: string }) => ({
          name: m.name,
          size: m.size ? `${Math.round(m.size / 1e9)}GB` : undefined,
          modified_at: m.modified_at,
        }));
      } else {
        // OpenAI-compatible
        const response = await fetch(`${this.config.baseUrl}/v1/models`, {
          headers: this.getHeaders(),
        });
        if (!response.ok) return [];

        const data = await response.json();
        return (data.data || []).map((m: { id: string }) => ({
          name: m.id,
        }));
      }
    } catch {
      return [];
    }
  }

  /**
   * Send a chat completion request
   */
  async chat(messages: ChatMessage[]): Promise<ChatResponse> {
    if (this.config.type === 'ollama') {
      return this.ollamaChat(messages);
    } else {
      return this.openAICompatibleChat(messages);
    }
  }

  /**
   * Generate embeddings for text
   */
  async embed(text: string): Promise<number[]> {
    try {
      if (this.config.type === 'ollama') {
        const response = await fetch(`${this.config.baseUrl}/api/embeddings`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: this.config.model,
            prompt: text,
          }),
        });

        if (!response.ok) {
          throw new Error(`Ollama embedding failed: ${response.statusText}`);
        }

        const data = await response.json();
        return data.embedding || [];
      } else {
        // OpenAI-compatible embedding
        const response = await fetch(`${this.config.baseUrl}/v1/embeddings`, {
          method: 'POST',
          headers: this.getHeaders(),
          body: JSON.stringify({
            model: this.config.model,
            input: text,
          }),
        });

        if (!response.ok) {
          throw new Error(`Embedding failed: ${response.statusText}`);
        }

        const data = await response.json();
        return data.data?.[0]?.embedding || [];
      }
    } catch (error) {
      console.error('Embedding error:', error);
      return [];
    }
  }

  // -------------------------------------------------------------------------
  // Private Methods
  // -------------------------------------------------------------------------

  private getHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this.config.apiKey) {
      headers['Authorization'] = `Bearer ${this.config.apiKey}`;
    }

    return headers;
  }

  private async ollamaChat(messages: ChatMessage[]): Promise<ChatResponse> {
    const response = await fetch(`${this.config.baseUrl}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: this.config.model,
        messages,
        stream: false,
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama chat failed: ${response.statusText}`);
    }

    const data = await response.json();
    return {
      content: data.message?.content || '',
      model: this.config.model,
      usage: {
        prompt_tokens: data.prompt_eval_count || 0,
        completion_tokens: data.eval_count || 0,
        total_tokens: (data.prompt_eval_count || 0) + (data.eval_count || 0),
      },
    };
  }

  private async openAICompatibleChat(messages: ChatMessage[]): Promise<ChatResponse> {
    const response = await fetch(`${this.config.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        model: this.config.model,
        messages,
        temperature: 0.7,
        max_tokens: 1024,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenAI-compatible chat failed: ${response.statusText} - ${errorText}`);
    }

    const data = await response.json();
    return {
      content: data.choices?.[0]?.message?.content || '',
      model: data.model || this.config.model,
      usage: data.usage,
    };
  }
}

// Singleton instance
let localLLMInstance: LocalLLMClient | null = null;

export function getLocalLLM(config?: Partial<LocalLLMConfig>): LocalLLMClient {
  if (!localLLMInstance) {
    localLLMInstance = new LocalLLMClient(config);
  } else if (config) {
    // Update config if provided
    localLLMInstance = new LocalLLMClient(config);
  }
  return localLLMInstance;
}

export function initLocalLLM(config: Partial<LocalLLMConfig>): LocalLLMClient {
  localLLMInstance = new LocalLLMClient(config);
  return localLLMInstance;
}

export default LocalLLMClient;
