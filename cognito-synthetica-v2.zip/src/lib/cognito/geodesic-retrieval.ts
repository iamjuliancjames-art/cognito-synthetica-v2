// =============================================================================
// Geodesic Best Fit Retrieval — Multi-Vector High-Speed Memory Access
//
// Optimizes memory retrieval using:
// 1. Multi-vector similarity (semantic + temporal + importance + kind + stability)
// 2. Graph-based geodesic traversal (follows pre-computed Lotus Cost edges)
// 3. Priority node caching (anchors, recent, high-importance)
// 4. Early termination for speed (returns when threshold met)
//
// Complexity: O(k log n) where k is path length, instead of O(n) linear scan
// =============================================================================

import { RoomStore, Room, TuningConfig, TUNING_LEVELS } from './engine';

// Multi-vector scoring weights
export interface MultiVectorWeights {
  semantic: number;    // Text similarity weight
  temporal: number;    // Recency weight
  importance: number;  // Pre-computed importance weight
  stability: number;   // Memory stability weight
  kind: number;        // Memory type priority weight
  graph: number;       // Graph connection weight
}

// Retrieval configuration
export interface GeodesicRetrievalConfig {
  maxPathLength: number;      // Maximum geodesic path length
  minScore: number;           // Minimum score threshold
  earlyTermination: boolean;  // Stop when good matches found
  diversityFactor: number;    // MMR lambda for diversity
  priorityBoost: number;      // Boost for priority nodes
  weights: MultiVectorWeights;
}

// Retrieval result with rich metadata
export interface GeodesicResult {
  room: Room;
  score: number;
  pathLength: number;       // How many hops from start
  components: {
    semantic: number;
    temporal: number;
    importance: number;
    stability: number;
    kind: number;
    graph: number;
  };
  isPriorityNode: boolean;
}

// Priority node cache
interface PriorityNodeCache {
  anchors: number[];           // Anchor node IDs
  recent: number[];            // Recently accessed node IDs
  highImportance: number[];    // High importance node IDs
  hubs: number[];              // Hub node IDs (connected to many)
  lastUpdate: number;          // Last cache update timestamp
}

// Default configurations
const DEFAULT_WEIGHTS: MultiVectorWeights = {
  semantic: 0.35,
  temporal: 0.15,
  importance: 0.20,
  stability: 0.10,
  kind: 0.10,
  graph: 0.10,
};

const DEFAULT_CONFIG: GeodesicRetrievalConfig = {
  maxPathLength: 6,
  minScore: 0.20,
  earlyTermination: true,
  diversityFactor: 0.7,
  priorityBoost: 1.5,
  weights: DEFAULT_WEIGHTS,
};

// Kind priority mapping
const KIND_PRIORITY: Record<string, number> = {
  semantic: 1.0,
  state: 0.95,
  commitment: 0.85,
  episodic: 0.6,
  page: 0.5,
  hub: 0.4,
  unknown: 0.3,
};

export class GeodesicRetrieval {
  private store: RoomStore;
  private tuning: TuningConfig;
  private config: GeodesicRetrievalConfig;
  private priorityCache: PriorityNodeCache;
  private cacheUpdateInterval: number = 60000; // 1 minute
  private eps: number = 1e-10;

  constructor(
    store: RoomStore,
    tuning: TuningConfig = TUNING_LEVELS.Gateway,
    config: Partial<GeodesicRetrievalConfig> = {}
  ) {
    this.store = store;
    this.tuning = tuning;
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.priorityCache = {
      anchors: [],
      recent: [],
      highImportance: [],
      hubs: [],
      lastUpdate: 0,
    };
    this.updatePriorityCache();
  }

  // -------------------------------------------------------------------------
  // Priority Node Caching - Fast Access to Important Memories
  // -------------------------------------------------------------------------

  private updatePriorityCache(): void {
    const now = Date.now();
    if (now - this.priorityCache.lastUpdate < this.cacheUpdateInterval) {
      return;
    }

    const rooms = this.store.getAllRooms();
    const oneHourAgo = now - 3600000;

    // Anchors (pre-defined important memories)
    this.priorityCache.anchors = Array.from(this.store.anchorIds);

    // Recent (accessed within last hour)
    this.priorityCache.recent = rooms
      .filter(r => r.meta.ts > oneHourAgo)
      .sort((a, b) => b.meta.ts - a.meta.ts)
      .slice(0, 50)
      .map(r => r.id);

    // High importance (top 20% by importance)
    const sortedByImportance = [...rooms].sort((a, b) => b.meta.importance - a.meta.importance);
    this.priorityCache.highImportance = sortedByImportance
      .slice(0, Math.max(20, Math.floor(rooms.length * 0.2)))
      .map(r => r.id);

    // Hubs (nodes with most graph connections)
    const connectionCounts: Array<[number, number]> = [];
    for (const [rid, neighbors] of this.store.graph) {
      connectionCounts.push([rid, neighbors.size]);
    }
    connectionCounts.sort((a, b) => b[1] - a[1]);
    this.priorityCache.hubs = connectionCounts
      .slice(0, 30)
      .map(([rid]) => rid);

    this.priorityCache.lastUpdate = now;
  }

  private isPriorityNode(rid: number): boolean {
    return (
      this.priorityCache.anchors.includes(rid) ||
      this.priorityCache.recent.includes(rid) ||
      this.priorityCache.highImportance.includes(rid) ||
      this.priorityCache.hubs.includes(rid)
    );
  }

  // -------------------------------------------------------------------------
  // Multi-Vector Scoring
  // -------------------------------------------------------------------------

  /**
   * Calculate multi-vector similarity score between query and room.
   * Returns both total score and individual components for transparency.
   */
  private calculateMultiVectorScore(
    query: string,
    room: Room,
    pathFromStart: number,
    now: number = Date.now()
  ): { total: number; components: GeodesicResult['components'] } {
    const weights = this.config.weights;
    const components: GeodesicResult['components'] = {
      semantic: 0,
      temporal: 0,
      importance: 0,
      stability: 0,
      kind: 0,
      graph: 0,
    };

    // 1. Semantic similarity (n-gram Jaccard)
    components.semantic = this.store.pseudoSim(query, room.canonical);

    // 2. Temporal proximity (recency)
    const ageHours = (now - room.meta.ts) / 3600000;
    components.temporal = 1 / (1 + ageHours * 0.1); // Decay over time

    // 3. Pre-computed importance
    components.importance = room.meta.importance;

    // 4. Stability score
    components.stability = room.meta.stability;

    // 5. Kind priority
    components.kind = KIND_PRIORITY[room.meta.kind] || 0.3;

    // 6. Graph proximity (closer to start = higher score)
    components.graph = 1 / (1 + pathFromStart * 0.2);

    // Weighted combination
    const total =
      weights.semantic * components.semantic +
      weights.temporal * components.temporal +
      weights.importance * components.importance +
      weights.stability * components.stability +
      weights.kind * components.kind +
      weights.graph * components.graph;

    // Boost priority nodes
    const boostedTotal = this.isPriorityNode(room.id)
      ? total * this.config.priorityBoost
      : total;

    return { total: Math.min(boostedTotal, 1), components };
  }

  // -------------------------------------------------------------------------
  // Geodesic Best Fit Algorithm
  // -------------------------------------------------------------------------

  /**
   * Find best-matching memories using geodesic traversal.
   * Starts from priority nodes and follows graph edges by Lotus Cost.
   */
  geodesicBestFit(
    query: string,
    topK: number = 6,
    maxHops: number = 3
  ): GeodesicResult[] {
    // Update cache if needed
    this.updatePriorityCache();

    const results: GeodesicResult[] = [];
    const visited = new Set<number>();
    const now = Date.now();

    // Phase 1: Direct scan of priority nodes (fast path)
    const priorityNodeIds = new Set([
      ...this.priorityCache.anchors,
      ...this.priorityCache.recent.slice(0, 20),
      ...this.priorityCache.highImportance.slice(0, 20),
    ]);

    for (const rid of priorityNodeIds) {
      if (visited.has(rid)) continue;
      visited.add(rid);

      const room = this.store.roomById(rid);
      if (!room || room.meta.archived) continue;

      const { total, components } = this.calculateMultiVectorScore(query, room, 0, now);

      if (total >= this.config.minScore) {
        results.push({
          room,
          score: total,
          pathLength: 0,
          components,
          isPriorityNode: true,
        });
      }
    }

    // Sort and check for early termination
    results.sort((a, b) => b.score - a.score);

    if (this.config.earlyTermination && results.length >= topK) {
      // Check if we have enough high-quality results
      const topAvgScore = results.slice(0, topK).reduce((s, r) => s + r.score, 0) / topK;
      if (topAvgScore > 0.6) {
        return this.applyDiversity(results, topK);
      }
    }

    // Phase 2: Geodesic traversal from best priority nodes
    const startNodes = results.slice(0, 3).map(r => r.room.id);
    if (startNodes.length === 0 && this.priorityCache.hubs.length > 0) {
      startNodes.push(...this.priorityCache.hubs.slice(0, 3));
    }

    for (const startId of startNodes) {
      this.traverseGeodesic(
        query,
        startId,
        visited,
        results,
        maxHops,
        now
      );
    }

    // Phase 3: If still not enough, scan high-importance nodes
    if (results.length < topK) {
      for (const rid of this.priorityCache.highImportance) {
        if (visited.has(rid)) continue;
        visited.add(rid);

        const room = this.store.roomById(rid);
        if (!room || room.meta.archived) continue;

        const { total, components } = this.calculateMultiVectorScore(query, room, 0, now);

        if (total >= this.config.minScore * 0.5) { // Lower threshold for fallback
          results.push({
            room,
            score: total,
            pathLength: 0,
            components,
            isPriorityNode: this.isPriorityNode(rid),
          });
        }
      }
    }

    // Sort and apply diversity
    results.sort((a, b) => b.score - a.score);
    return this.applyDiversity(results, topK);
  }

  /**
   * Traverse graph edges following Lotus Cost (geodesic path).
   */
  private traverseGeodesic(
    query: string,
    startId: number,
    visited: Set<number>,
    results: GeodesicResult[],
    maxHops: number,
    now: number
  ): void {
    // Priority queue: [lotusCost, currentId, hopCount]
    const pq: Array<[number, number, number]> = [[0, startId, 0]];
    const bestCost = new Map<number, number>();

    while (pq.length > 0) {
      // Sort by cost and get minimum
      pq.sort((a, b) => a[0] - b[0]);
      const [currentCost, currentId, hops] = pq.shift()!;

      // Skip if already visited with lower cost
      if (visited.has(currentId) && (bestCost.get(currentId) || Infinity) <= currentCost) {
        continue;
      }

      visited.add(currentId);
      bestCost.set(currentId, currentCost);

      // Get current room and score
      const room = this.store.roomById(currentId);
      if (!room || room.meta.archived) continue;

      const { total, components } = this.calculateMultiVectorScore(query, room, hops, now);

      if (total >= this.config.minScore) {
        results.push({
          room,
          score: total,
          pathLength: hops,
          components,
          isPriorityNode: this.isPriorityNode(currentId),
        });
      }

      // Stop if max hops reached
      if (hops >= maxHops) continue;

      // Explore neighbors by Lotus Cost
      const neighbors = this.store.graph.get(currentId);
      if (!neighbors) continue;

      for (const [neighborId, edgeCost] of neighbors) {
        if (visited.has(neighborId)) continue;

        const newCost = currentCost + edgeCost;
        if (newCost < (bestCost.get(neighborId) || Infinity)) {
          pq.push([newCost, neighborId, hops + 1]);
        }
      }
    }
  }

  // -------------------------------------------------------------------------
  // Diversity (MMR) for Rich Context
  // -------------------------------------------------------------------------

  /**
   * Apply Maximal Marginal Relevance for diverse results.
   * Balances relevance with novelty.
   */
  private applyDiversity(results: GeodesicResult[], topK: number): GeodesicResult[] {
    if (results.length <= topK || !this.config.diversityFactor) {
      return results.slice(0, topK);
    }

    const lam = this.config.diversityFactor;
    const selected: GeodesicResult[] = [results[0]];
    const remaining = [...results.slice(1)];

    while (selected.length < topK && remaining.length > 0) {
      let bestIdx = 0;
      let bestMmr = -Infinity;

      for (let i = 0; i < remaining.length; i++) {
        const candidate = remaining[i];

        // Find max similarity to already selected
        let maxSim = 0;
        for (const sel of selected) {
          const sim = this.store.pseudoSim(candidate.room.canonical, sel.room.canonical);
          maxSim = Math.max(maxSim, sim);
        }

        // MMR = λ * relevance - (1-λ) * redundancy
        const mmr = lam * candidate.score - (1 - lam) * maxSim;

        if (mmr > bestMmr) {
          bestMmr = mmr;
          bestIdx = i;
        }
      }

      selected.push(remaining[bestIdx]);
      remaining.splice(bestIdx, 1);
    }

    return selected;
  }

  // -------------------------------------------------------------------------
  // Fast Context Retrieval for Chat
  // -------------------------------------------------------------------------

  /**
   * Optimized retrieval for chat context.
   * Returns formatted context string for LLM.
   */
  retrieveChatContext(
    query: string,
    maxTokens: number = 2000
  ): { context: string; results: GeodesicResult[]; tokenCount: number } {
    const results = this.geodesicBestFit(query, 8, 4);

    let context = "";
    let tokenCount = 0;
    const avgTokenPerChar = 0.25; // Approximate

    for (const result of results) {
      const entry = `[${result.room.meta.kind}] (score: ${result.score.toFixed(2)}) ${result.room.canonical}\n`;
      const entryTokens = entry.length * avgTokenPerChar;

      if (tokenCount + entryTokens > maxTokens) break;

      context += entry;
      tokenCount += entryTokens;
    }

    return { context, results, tokenCount: Math.floor(tokenCount) };
  }

  // -------------------------------------------------------------------------
  // Status and Configuration
  // -------------------------------------------------------------------------

  getStatus(): {
    cacheSize: number;
    cacheAge: number;
    config: GeodesicRetrievalConfig;
  } {
    return {
      cacheSize: new Set([
        ...this.priorityCache.anchors,
        ...this.priorityCache.recent,
        ...this.priorityCache.highImportance,
        ...this.priorityCache.hubs,
      ]).size,
      cacheAge: Date.now() - this.priorityCache.lastUpdate,
      config: this.config,
    };
  }

  updateConfig(config: Partial<GeodesicRetrievalConfig>): void {
    this.config = { ...this.config, ...config };
  }

  updateWeights(weights: Partial<MultiVectorWeights>): void {
    this.config.weights = { ...this.config.weights, ...weights };
  }

  /**
   * Force cache refresh.
   */
  refreshCache(): void {
    this.priorityCache.lastUpdate = 0;
    this.updatePriorityCache();
  }
}

// Singleton instance
let geodesicRetrievalInstance: GeodesicRetrieval | null = null;

export function getGeodesicRetrieval(
  store?: RoomStore,
  tuning?: TuningConfig,
  config?: Partial<GeodesicRetrievalConfig>
): GeodesicRetrieval {
  if (!geodesicRetrievalInstance && store) {
    geodesicRetrievalInstance = new GeodesicRetrieval(store, tuning, config);
  } else if (!geodesicRetrievalInstance) {
    throw new Error('GeodesicRetrieval not initialized. Provide store first.');
  }
  return geodesicRetrievalInstance;
}

export function initGeodesicRetrieval(
  store: RoomStore,
  tuning?: TuningConfig,
  config?: Partial<GeodesicRetrievalConfig>
): GeodesicRetrieval {
  geodesicRetrievalInstance = new GeodesicRetrieval(store, tuning, config);
  return geodesicRetrievalInstance;
}

export default GeodesicRetrieval;
