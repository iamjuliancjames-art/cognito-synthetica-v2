// =============================================================================
// Shared State Module - Ensures singleton instances across all API routes
// In development mode with hot reloading, module state can be lost between routes.
// This file provides a centralized singleton pattern.
// =============================================================================

import { CognitoSynthetica, TUNING_LEVELS, TuningConfig, RoomStore } from '@/lib/cognito/engine';
import type { PulseMemory } from '@/lib/cognito/pulse-memory';
import type { LLMMemoryAccumulator } from '@/lib/cognito/llm-memory';

// Global singleton storage using globalThis to persist across hot reloads
declare global {
  // eslint-disable-next-line no-var
  var __cognitoInstance: CognitoSynthetica | undefined;
  // eslint-disable-next-line no-var
  var __pulseMemoryInstance: PulseMemory | undefined;
  // eslint-disable-next-line no-var
  var __llmMemoryInstance: LLMMemoryAccumulator | undefined;
}

// Get or create the Cognito instance
export function getSharedCognito(tuning: string = "Gateway"): CognitoSynthetica {
  if (!globalThis.__cognitoInstance) {
    globalThis.__cognitoInstance = new CognitoSynthetica(tuning);
    console.log('[SharedState] Created new CognitoSynthetica instance');
  }
  return globalThis.__cognitoInstance;
}

// Get the Cognito instance (alias for compatibility)
export function getCognitoInstance(tuning?: string): CognitoSynthetica {
  return getSharedCognito(tuning);
}

// Get the RoomStore from Cognito
export function getSharedStore(): RoomStore {
  return getSharedCognito().getStore();
}

// Get the TuningConfig
export function getSharedTuning(): TuningConfig {
  return getSharedCognito().getTuning();
}

// Reset all instances
export function resetSharedState(tuning: string = "Gateway"): void {
  globalThis.__cognitoInstance = new CognitoSynthetica(tuning);
  globalThis.__pulseMemoryInstance = undefined;
  globalThis.__llmMemoryInstance = undefined;
  console.log('[SharedState] All instances reset');
}

// Get status info
export function getSharedStatus(): {
  cognitoReady: boolean;
  roomCount: number;
  anchorCount: number;
  attractorCount: number;
} {
  const cognito = globalThis.__cognitoInstance;
  const store = cognito?.getStore();
  
  return {
    cognitoReady: !!cognito,
    roomCount: store?.getAllRooms().length || 0,
    anchorCount: store?.anchorIds?.size || 0,
    attractorCount: store?.attractors?.length || 0,
  };
}
