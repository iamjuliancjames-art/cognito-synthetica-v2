'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { 
  Brain, Search, Database, Shield, Moon, Activity, RefreshCw, 
  Plus, Zap, Lock, AlertTriangle, CheckCircle2, Network, Settings,
  Clock, TrendingUp, Target, Sparkles, Trash2, MessageCircle, Send, User, Bot,
  Download, Upload, Code, FileJson, Copy, Check
} from 'lucide-react'

// Types
interface Memory {
  id: number
  canonical: string
  kind: string
  score?: number
  importance: number
  stability: number
  novelty: number
  ts: number
  archived?: boolean
}

interface GraphNode {
  id: number
  label: string
  kind: string
}

interface GraphEdge {
  source: number
  target: number
  weight: number
}

interface GraphData {
  nodes: GraphNode[]
  edges: GraphEdge[]
}

interface TuningConfig {
  SIM_THRESHOLD: number
  NOVELTY_GATE: number
  SYMBIOSIS_THRESHOLD: number
  LAMBDA_PI: number
  MU_RISK: number
  SINGULARITY_GATE: number
}

interface TalosResult {
  stable: boolean
  entropy: number
  coherence: number
  nudge: string | null
}

interface GuardResult {
  safe: boolean
  risk: number
  reason: string
}

interface DreamEvent {
  reflect_hub: number | null
  archived_count: number
  message: string
}

interface TuningLevels {
  [key: string]: TuningConfig
}

interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
  timestamp: number
}

interface ChatResponse {
  success: boolean
  response?: string
  memories_used?: number
  memories_stored?: number
  stored_memories?: string[]
  security?: { risk: number; safe: boolean }
  error?: string
}

export default function CognitoSyntheticaUI() {
  // State
  const [status, setStatus] = useState<string>('')
  const [tuning, setTuning] = useState<string>('Gateway')
  const [tuningConfigs, setTuningConfigs] = useState<TuningLevels>({})
  const [currentTuningConfig, setCurrentTuningConfig] = useState<TuningConfig | null>(null)
  
  // Memory state
  const [memories, setMemories] = useState<Memory[]>([])
  const [searchResults, setSearchResults] = useState<Memory[]>([])
  const [recallResults, setRecallResults] = useState<Memory[]>([])
  
  // Form inputs
  const [newMemoryText, setNewMemoryText] = useState('')
  const [newMemoryKind, setNewMemoryKind] = useState('episodic')
  const [isAnchor, setIsAnchor] = useState(false)
  const [isAttractor, setIsAttractor] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [recallQuery, setRecallQuery] = useState('')
  const [guardQuery, setGuardQuery] = useState('')
  const [talosText, setTalosText] = useState('')
  
  // Results
  const [guardResult, setGuardResult] = useState<GuardResult | null>(null)
  const [talosResult, setTalosResult] = useState<TalosResult | null>(null)
  const [dreamEvent, setDreamEvent] = useState<DreamEvent | null>(null)
  
  // Graph
  const [graph, setGraph] = useState<GraphData | null>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  
  // UI state
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState('memories')
  
  // Chat state
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])
  const [chatInput, setChatInput] = useState('')
  const [chatLoading, setChatLoading] = useState(false)
  const [lastChatInfo, setLastChatInfo] = useState<{memoriesUsed: number, memoriesStored: number} | null>(null)
  const chatScrollRef = useRef<HTMLDivElement>(null)
  
  // Local LLM state
  const [useLocalLLM, setUseLocalLLM] = useState(false)
  const [localLLMUrl, setLocalLLMUrl] = useState('http://localhost:1234')
  const [localLLMModel, setLocalLLMModel] = useState('gemma-3')
  
  // Code viewer state
  const [codeFiles, setCodeFiles] = useState<Record<string, string>>({})
  const [selectedFile, setSelectedFile] = useState<string>('')
  const [copiedFile, setCopiedFile] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  // Reference LLM state
  const [refLLMStatus, setRefLLMStatus] = useState<{
    totalExamples: number;
    totalKnowledge: number;
    estimatedTokens: number;
    metabolismCount: number;
    pendingCount: number;
    isActive: boolean;
    lastMetabolism: number | null;
  } | null>(null)
  const [refLLMKnowledge, setRefLLMKnowledge] = useState<Array<{
    id: string;
    concept: string;
    summary: string;
    confidence: number;
    accessCount: number;
  }>>([])
  const [metabolismResult, setMetabolismResult] = useState<{
    processed: number;
    newKnowledge: number;
    consolidated: number;
    archived: number;
    insights: string[];
  } | null>(null)
  
  // Pulse Memory state
  const [pulseStatus, setPulseStatus] = useState<{
    isActive: boolean;
    lastPulse: number | null;
    pulseCount: number;
    totalNodesVisited: number;
    totalInsights: number;
    totalPathsStrengthened: number;
  } | null>(null)
  const [pulseResult, setPulseResult] = useState<{
    success: boolean;
    path: {
      nodeIds: number[];
      totalCost: number;
      coverage: number;
      insights: string[];
      pathStrength: number;
    } | null;
    insights: string[];
    nodesVisited: number;
    pathsStrengthened: number;
    duration: number;
  } | null>(null)
  const [storeInfo, setStoreInfo] = useState<{roomCount: number; graphEdges: number} | null>(null)

  // Fetch status
  const fetchStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/cognito?action=status')
      const data = await res.json()
      if (data.success) {
        setStatus(data.status)
        setCurrentTuningConfig(data.tuning)
      }
    } catch (error) {
      console.error('Failed to fetch status:', error)
    }
  }, [])

  // Fetch tuning levels
  const fetchTuningLevels = useCallback(async () => {
    try {
      const res = await fetch('/api/cognito?action=tuning_levels')
      const data = await res.json()
      if (data.success) {
        setTuningConfigs(data.configs)
      }
    } catch (error) {
      console.error('Failed to fetch tuning levels:', error)
    }
  }, [])

  // Fetch memories
  const fetchMemories = useCallback(async () => {
    try {
      const res = await fetch('/api/cognito?action=memories')
      const data = await res.json()
      if (data.success) {
        setMemories(data.memories)
      }
    } catch (error) {
      console.error('Failed to fetch memories:', error)
    }
  }, [])

  // Initialize
  useEffect(() => {
    const initialize = async () => {
      // Fetch status
      try {
        const res = await fetch('/api/cognito?action=status')
        const data = await res.json()
        if (data.success) {
          setStatus(data.status)
          setCurrentTuningConfig(data.tuning)
        }
      } catch (error) {
        console.error('Failed to fetch status:', error)
      }
      
      // Fetch tuning levels
      try {
        const res = await fetch('/api/cognito?action=tuning_levels')
        const data = await res.json()
        if (data.success) {
          setTuningConfigs(data.configs)
        }
      } catch (error) {
        console.error('Failed to fetch tuning levels:', error)
      }
      
      // Fetch memories
      try {
        const res = await fetch('/api/cognito?action=memories')
        const data = await res.json()
        if (data.success) {
          setMemories(data.memories)
        }
      } catch (error) {
        console.error('Failed to fetch memories:', error)
      }
    }
    initialize()
  }, [])

  // Draw graph on canvas
  useEffect(() => {
    if (!graph || !canvasRef.current) return
    
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height

    // Clear canvas
    ctx.fillStyle = '#0a0a0f'
    ctx.fillRect(0, 0, width, height)

    if (graph.nodes.length === 0) return

    // Calculate node positions using simple force-directed layout
    const nodePositions = new Map<number, { x: number; y: number }>()
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) / 3

    // Place nodes in a circle initially
    graph.nodes.forEach((node, i) => {
      const angle = (2 * Math.PI * i) / graph.nodes.length
      nodePositions.set(node.id, {
        x: centerX + radius * Math.cos(angle),
        y: centerY + radius * Math.sin(angle)
      })
    })

    // Draw edges
    ctx.strokeStyle = 'rgba(100, 150, 255, 0.3)'
    ctx.lineWidth = 1
    for (const edge of graph.edges) {
      const source = nodePositions.get(edge.source)
      const target = nodePositions.get(edge.target)
      if (source && target) {
        ctx.beginPath()
        ctx.moveTo(source.x, source.y)
        ctx.lineTo(target.x, target.y)
        ctx.stroke()
      }
    }

    // Draw nodes
    const kindColors: Record<string, string> = {
      semantic: '#3b82f6',
      state: '#10b981',
      commitment: '#f59e0b',
      episodic: '#8b5cf6',
      hub: '#ef4444',
      page: '#06b6d4',
      unknown: '#6b7280'
    }

    for (const node of graph.nodes) {
      const pos = nodePositions.get(node.id)
      if (!pos) continue

      const color = kindColors[node.kind] || kindColors.unknown
      
      // Draw node circle
      ctx.beginPath()
      ctx.arc(pos.x, pos.y, 8, 0, 2 * Math.PI)
      ctx.fillStyle = color
      ctx.fill()
      ctx.strokeStyle = '#fff'
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw label
      ctx.fillStyle = '#fff'
      ctx.font = '10px system-ui'
      ctx.textAlign = 'center'
      ctx.fillText(node.label.slice(0, 15), pos.x, pos.y + 20)
    }
  }, [graph])

  // Add memory
  const handleAddMemory = async () => {
    if (!newMemoryText.trim()) return
    
    setLoading(true)
    try {
      const res = await fetch('/api/cognito', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'add_memory',
          text: newMemoryText,
          kind: newMemoryKind,
          isAnchor,
          attractor: isAttractor
        })
      })
      const data = await res.json()
      if (data.success) {
        setNewMemoryText('')
        fetchMemories()
        fetchStatus()
      }
    } catch (error) {
      console.error('Failed to add memory:', error)
    }
    setLoading(false)
  }

  // Search
  const handleSearch = async () => {
    if (!searchQuery.trim()) return
    
    setLoading(true)
    try {
      const res = await fetch(`/api/cognito?action=search&query=${encodeURIComponent(searchQuery)}`)
      const data = await res.json()
      if (data.success) {
        setSearchResults(data.results)
      }
    } catch (error) {
      console.error('Failed to search:', error)
    }
    setLoading(false)
  }

  // Recall
  const handleRecall = async () => {
    if (!recallQuery.trim()) return
    
    setLoading(true)
    try {
      const res = await fetch(`/api/cognito?action=recall&query=${encodeURIComponent(recallQuery)}`)
      const data = await res.json()
      if (data.success) {
        setRecallResults(data.results)
      }
    } catch (error) {
      console.error('Failed to recall:', error)
    }
    setLoading(false)
  }

  // Guard query
  const handleGuard = async () => {
    if (!guardQuery.trim()) return
    
    setLoading(true)
    try {
      const res = await fetch(`/api/cognito?action=guard&query=${encodeURIComponent(guardQuery)}`)
      const data = await res.json()
      if (data.success) {
        setGuardResult(data.guard)
      }
    } catch (error) {
      console.error('Failed to guard:', error)
    }
    setLoading(false)
  }

  // Talos check
  const handleTalos = async () => {
    if (!talosText.trim()) return
    
    setLoading(true)
    try {
      const res = await fetch(`/api/cognito?action=talos&text=${encodeURIComponent(talosText)}`)
      const data = await res.json()
      if (data.success) {
        setTalosResult(data.talos)
      }
    } catch (error) {
      console.error('Failed to talos check:', error)
    }
    setLoading(false)
  }

  // Dream tick
  const handleDream = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/cognito?action=tick')
      const data = await res.json()
      if (data.success) {
        setDreamEvent(data.event)
        fetchMemories()
        fetchStatus()
      }
    } catch (error) {
      console.error('Failed to dream:', error)
    }
    setLoading(false)
  }

  // Fetch graph
  const handleFetchGraph = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/cognito?action=graph')
      const data = await res.json()
      if (data.success) {
        setGraph(data.graph)
      }
    } catch (error) {
      console.error('Failed to fetch graph:', error)
    }
    setLoading(false)
  }

  // Change tuning
  const handleTuningChange = async (newTuning: string) => {
    setTuning(newTuning)
    try {
      const res = await fetch('/api/cognito', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'set_tuning', tuning: newTuning })
      })
      const data = await res.json()
      if (data.success) {
        setCurrentTuningConfig(data.tuning)
        fetchStatus()
      }
    } catch (error) {
      console.error('Failed to change tuning:', error)
    }
  }

  // Reset system
  const handleReset = async () => {
    if (!confirm('This will reset the entire cognitive system. Are you sure?')) return
    
    setLoading(true)
    try {
      await fetch('/api/cognito', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reset', tuning })
      })
      setMemories([])
      setSearchResults([])
      setRecallResults([])
      setGuardResult(null)
      setTalosResult(null)
      setDreamEvent(null)
      setGraph(null)
      fetchStatus()
    } catch (error) {
      console.error('Failed to reset:', error)
    }
    setLoading(false)
  }

  // Add demo memories
  const handleAddDemoMemories = async () => {
    setLoading(true)
    try {
      await fetch('/api/cognito', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'bulk_add',
          memories: [
            { text: "Building Cognito Synthetica - a cognitive architecture for synthetic minds", kind: "commitment", isAnchor: true },
            { text: "Maintain creative momentum and explore new possibilities", kind: "state", attractor: true },
            { text: "The hippocampus is responsible for memory formation and spatial navigation", kind: "semantic" },
            { text: "Learned about BM25 scoring and its application in search engines", kind: "episodic" },
            { text: "Neural networks can approximate any continuous function given enough neurons", kind: "semantic" },
            { text: "Implemented O(1) lookups using Map instead of O(N) list iteration", kind: "episodic" },
            { text: "The lotus cost function combines distance, entropy proxy, and risk factors", kind: "semantic" },
            { text: "Graph-based memory connections enable associative recall", kind: "semantic" },
          ]
        })
      })
      fetchMemories()
      fetchStatus()
    } catch (error) {
      console.error('Failed to add demo memories:', error)
    }
    setLoading(false)
  }

  // Export memories
  const handleExport = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/cognito?action=export')
      const data = await res.json()
      if (data.success) {
        const blob = new Blob([JSON.stringify(data.data, null, 2)], { type: 'application/json' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `cognito-memory-${new Date().toISOString().slice(0, 10)}.json`
        a.click()
        URL.revokeObjectURL(url)
      }
    } catch (error) {
      console.error('Failed to export:', error)
    }
    setLoading(false)
  }

  // Import memories from file (supports JSON, JSONL, TXT, and PDF)
  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    
    setLoading(true)
    try {
      const isPdf = file.name.toLowerCase().endsWith('.pdf')
      
      if (isPdf) {
        // Handle PDF files using base64 encoding
        const arrayBuffer = await file.arrayBuffer()
        const base64 = btoa(
          new Uint8Array(arrayBuffer).reduce(
            (data, byte) => data + String.fromCharCode(byte),
            ''
          )
        )
        
        const res = await fetch('/api/cognito', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'import_file',
            content: base64,
            filename: file.name,
            isBase64: true
          })
        })
        const data = await res.json()
        if (data.success) {
          fetchMemories()
          fetchStatus()
          alert(`PDF "${file.name}" processed:\n- Pages: ${data.pages}\n- Memory chunks: ${data.chunks}\n- Total memories stored: ${data.imported}\n\nPreview: ${data.preview?.slice(0, 200)}...`)
        } else {
          alert(`Error: ${data.error}`)
        }
      } else {
        // Handle text/JSON files
        const text = await file.text()
        const res = await fetch('/api/cognito', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'import_file',
            content: text,
            filename: file.name
          })
        })
        const data = await res.json()
        if (data.success) {
          fetchMemories()
          fetchStatus()
          alert(`Imported ${data.imported} memories from ${file.name}`)
        } else {
          alert(`Error: ${data.error}`)
        }
      }
    } catch (error) {
      console.error('Failed to import:', error)
      alert('Failed to import file. Please try again.')
    }
    setLoading(false)
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  // Fetch code files
  const handleFetchCode = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/cognito?action=code')
      const data = await res.json()
      if (data.success) {
        setCodeFiles(data.files)
        setSelectedFile(Object.keys(data.files)[0] || '')
      }
    } catch (error) {
      console.error('Failed to fetch code:', error)
    }
    setLoading(false)
  }

  // Copy code to clipboard
  const handleCopyCode = async () => {
    if (!selectedFile || !codeFiles[selectedFile]) return
    try {
      await navigator.clipboard.writeText(codeFiles[selectedFile])
      setCopiedFile(true)
      setTimeout(() => setCopiedFile(false), 2000)
    } catch (error) {
      console.error('Failed to copy:', error)
    }
  }

  // Chat with LLM
  const handleChat = async () => {
    if (!chatInput.trim() || chatLoading) return
    
    const userMessage: ChatMessage = {
      role: 'user',
      content: chatInput,
      timestamp: Date.now()
    }
    
    setChatMessages(prev => [...prev, userMessage])
    setChatInput('')
    setChatLoading(true)
    
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...chatMessages, userMessage].map(m => ({
            role: m.role,
            content: m.content
          })),
          useLocalLLM,
          localLLMUrl,
          localLLMModel,
        })
      })
      
      const data: ChatResponse = await res.json()
      
      if (data.success && data.response) {
        const assistantMessage: ChatMessage = {
          role: 'assistant',
          content: data.response,
          timestamp: Date.now()
        }
        setChatMessages(prev => [...prev, assistantMessage])
        setLastChatInfo({
          memoriesUsed: data.memories_used || 0,
          memoriesStored: data.memories_stored || 0
        })
        
        // Refresh memories if new ones were stored
        if (data.memories_stored && data.memories_stored > 0) {
          fetchMemories()
          fetchStatus()
        }
      } else {
        const errorMessage: ChatMessage = {
          role: 'assistant',
          content: `Error: ${data.error || 'Unknown error'}`,
          timestamp: Date.now()
        }
        setChatMessages(prev => [...prev, errorMessage])
      }
    } catch (error) {
      console.error('Chat error:', error)
      const errorMessage: ChatMessage = {
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again.',
        timestamp: Date.now()
      }
      setChatMessages(prev => [...prev, errorMessage])
    }
    
    setChatLoading(false)
  }

  // Auto-scroll chat
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight
    }
  }, [chatMessages])

  // Fetch Reference LLM status
  const fetchRefLLMStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/reference-llm?action=status')
      const data = await res.json()
      if (data.success) {
        setRefLLMStatus(data.status)
      }
    } catch (error) {
      console.error('Failed to fetch Reference LLM status:', error)
    }
  }, [])

  // Fetch Reference LLM knowledge
  const fetchRefLLMKnowledge = useCallback(async () => {
    try {
      const res = await fetch('/api/reference-llm?action=knowledge&limit=20')
      const data = await res.json()
      if (data.success) {
        setRefLLMKnowledge(data.knowledge)
      }
    } catch (error) {
      console.error('Failed to fetch Reference LLM knowledge:', error)
    }
  }, [])

  // Run metabolism
  const handleMetabolism = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/reference-llm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'metabolize' })
      })
      const data = await res.json()
      if (data.success) {
        setMetabolismResult(data.result)
        fetchRefLLMStatus()
        fetchRefLLMKnowledge()
      }
    } catch (error) {
      console.error('Failed to run metabolism:', error)
    }
    setLoading(false)
  }

  // Start/stop auto metabolism
  const handleToggleAutoMetabolism = async () => {
    setLoading(true)
    try {
      const action = refLLMStatus?.isActive ? 'stop_auto' : 'start_auto'
      await fetch('/api/reference-llm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      })
      fetchRefLLMStatus()
    } catch (error) {
      console.error('Failed to toggle auto metabolism:', error)
    }
    setLoading(false)
  }

  // Export Reference LLM data
  const handleExportRefLLM = async () => {
    try {
      const res = await fetch('/api/reference-llm?action=export')
      const data = await res.json()
      if (data.success) {
        const blob = new Blob([JSON.stringify(data.data, null, 2)], { type: 'application/json' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `reference-llm-${new Date().toISOString().slice(0, 10)}.json`
        a.click()
        URL.revokeObjectURL(url)
      }
    } catch (error) {
      console.error('Failed to export Reference LLM:', error)
    }
  }
  
  // Fetch Pulse Memory status
  const fetchPulseStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/pulse-memory?action=status')
      const data = await res.json()
      if (data.success) {
        setPulseStatus(data.state)
        setStoreInfo(data.store)
      }
    } catch (error) {
      console.error('Failed to fetch Pulse Memory status:', error)
    }
  }, [])

  // Execute a pulse
  const handlePulse = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/pulse-memory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'pulse' })
      })
      const data = await res.json()
      if (data.success) {
        setPulseResult(data.result)
        fetchPulseStatus()
        fetchMemories()
        fetchStatus()
      }
    } catch (error) {
      console.error('Failed to execute pulse:', error)
    }
    setLoading(false)
  }

  // Toggle auto pulse
  const handleToggleAutoPulse = async () => {
    setLoading(true)
    try {
      const action = pulseStatus?.isActive ? 'stop_auto' : 'start_auto'
      await fetch('/api/pulse-memory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      })
      fetchPulseStatus()
    } catch (error) {
      console.error('Failed to toggle auto pulse:', error)
    }
    setLoading(false)
  }

  const kindColors: Record<string, string> = {
    semantic: 'bg-blue-500',
    state: 'bg-green-500',
    commitment: 'bg-amber-500',
    episodic: 'bg-purple-500',
    hub: 'bg-red-500',
    page: 'bg-cyan-500',
    unknown: 'bg-gray-500'
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-white p-4 md:p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <Brain className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
                Cognito Synthetica
              </h1>
              <p className="text-sm text-slate-400">Cognitive Architecture v2.0</p>
            </div>
          </div>
          
          <div className="flex flex-wrap items-center gap-3">
            <Badge variant="outline" className="border-indigo-500 text-indigo-400">
              <Activity className="w-3 h-3 mr-1" />
              {status || 'Loading...'}
            </Badge>
            
            <Select value={tuning} onValueChange={handleTuningChange}>
              <SelectTrigger className="w-36 bg-slate-800 border-slate-700">
                <Shield className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Unfettered">Unfettered</SelectItem>
                <SelectItem value="Gateway">Gateway</SelectItem>
                <SelectItem value="Fort Knox">Fort Knox</SelectItem>
                <SelectItem value="Total Lockdown">Total Lockdown</SelectItem>
              </SelectContent>
            </Select>

            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleReset}
              className="border-red-500/50 text-red-400 hover:bg-red-500/10"
            >
              <Trash2 className="w-4 h-4 mr-1" />
              Reset
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-slate-800/50 border border-slate-700">
            <TabsTrigger value="memories" className="data-[state=active]:bg-indigo-600">
              <Database className="w-4 h-4 mr-2" />
              Memories
            </TabsTrigger>
            <TabsTrigger value="search" className="data-[state=active]:bg-indigo-600">
              <Search className="w-4 h-4 mr-2" />
              Search
            </TabsTrigger>
            <TabsTrigger value="recall" className="data-[state=active]:bg-indigo-600">
              <Brain className="w-4 h-4 mr-2" />
              Recall
            </TabsTrigger>
            <TabsTrigger value="graph" className="data-[state=active]:bg-indigo-600">
              <Network className="w-4 h-4 mr-2" />
              Graph
            </TabsTrigger>
            <TabsTrigger value="security" className="data-[state=active]:bg-indigo-600">
              <Shield className="w-4 h-4 mr-2" />
              Security
            </TabsTrigger>
            <TabsTrigger value="dream" className="data-[state=active]:bg-indigo-600">
              <Moon className="w-4 h-4 mr-2" />
              Dream
            </TabsTrigger>
            <TabsTrigger value="chat" className="data-[state=active]:bg-indigo-600">
              <MessageCircle className="w-4 h-4 mr-2" />
              Chat
            </TabsTrigger>
            <TabsTrigger value="refllm" className="data-[state=active]:bg-indigo-600">
              <Sparkles className="w-4 h-4 mr-2" />
              RefLLM
            </TabsTrigger>
            <TabsTrigger value="pulse" className="data-[state=active]:bg-indigo-600">
              <Zap className="w-4 h-4 mr-2" />
              Pulse
            </TabsTrigger>
            <TabsTrigger value="code" className="data-[state=active]:bg-indigo-600">
              <Code className="w-4 h-4 mr-2" />
              Code
            </TabsTrigger>
          </TabsList>

          {/* Memories Tab */}
          <TabsContent value="memories" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              {/* Add Memory Card */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Plus className="w-5 h-5 text-indigo-400" />
                    Add Memory
                  </CardTitle>
                  <CardDescription>Add a new memory to the cognitive store</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Memory Text</Label>
                    <Textarea
                      value={newMemoryText}
                      onChange={(e) => setNewMemoryText(e.target.value)}
                      placeholder="Enter memory content..."
                      className="bg-slate-900 border-slate-600 min-h-24"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Kind</Label>
                      <Select value={newMemoryKind} onValueChange={setNewMemoryKind}>
                        <SelectTrigger className="bg-slate-900 border-slate-600">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="episodic">Episodic</SelectItem>
                          <SelectItem value="semantic">Semantic</SelectItem>
                          <SelectItem value="state">State</SelectItem>
                          <SelectItem value="commitment">Commitment</SelectItem>
                          <SelectItem value="page">Page</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="anchor" className="text-sm">Anchor</Label>
                        <Switch id="anchor" checked={isAnchor} onCheckedChange={setIsAnchor} />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="attractor" className="text-sm">Attractor</Label>
                        <Switch id="attractor" checked={isAttractor} onCheckedChange={setIsAttractor} />
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 flex-wrap">
                    <Button 
                      onClick={handleAddMemory} 
                      disabled={loading || !newMemoryText.trim()}
                      className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Memory
                    </Button>
                    <Button 
                      onClick={handleAddDemoMemories} 
                      variant="outline"
                      disabled={loading}
                      className="border-slate-600"
                    >
                      <Sparkles className="w-4 h-4 mr-2" />
                      Demo
                    </Button>
                  </div>
                  
                  {/* Export/Import Buttons */}
                  <div className="flex gap-2 pt-2">
                    <Button 
                      onClick={handleExport} 
                      variant="outline"
                      disabled={loading || memories.length === 0}
                      className="flex-1 border-green-500/50 text-green-400 hover:bg-green-500/10"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </Button>
                    <Button 
                      onClick={() => fileInputRef.current?.click()} 
                      variant="outline"
                      disabled={loading}
                      className="flex-1 border-blue-500/50 text-blue-400 hover:bg-blue-500/10"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Import (PDF/JSON)
                    </Button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".json,.jsonl,.txt,.pdf"
                      onChange={handleImportFile}
                      className="hidden"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Tuning Config Card */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Settings className="w-5 h-5 text-indigo-400" />
                    Current Tuning: {tuning}
                  </CardTitle>
                  <CardDescription>Active tuning configuration parameters</CardDescription>
                </CardHeader>
                <CardContent>
                  {currentTuningConfig && (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">SIM_THRESHOLD</span>
                          <div className="font-mono text-indigo-400">{currentTuningConfig.SIM_THRESHOLD}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">NOVELTY_GATE</span>
                          <div className="font-mono text-indigo-400">{currentTuningConfig.NOVELTY_GATE}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">SYMBIOSIS_THRESHOLD</span>
                          <div className="font-mono text-indigo-400">{currentTuningConfig.SYMBIOSIS_THRESHOLD}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">LAMBDA_PI</span>
                          <div className="font-mono text-indigo-400">{currentTuningConfig.LAMBDA_PI}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">MU_RISK</span>
                          <div className="font-mono text-indigo-400">{currentTuningConfig.MU_RISK}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">SINGULARITY_GATE</span>
                          <div className="font-mono text-indigo-400">{currentTuningConfig.SINGULARITY_GATE}</div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Memory List */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Database className="w-5 h-5 text-indigo-400" />
                  Memory Store ({memories.length} memories)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  {memories.length === 0 ? (
                    <div className="text-center text-slate-400 py-8">
                      <Database className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No memories yet. Add some memories or load demo data.</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {memories.map((memory) => (
                        <div 
                          key={memory.id}
                          className="bg-slate-900/50 p-3 rounded-lg border border-slate-700 hover:border-slate-600 transition-colors"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <Badge className={`${kindColors[memory.kind]} text-white text-xs`}>
                                  {memory.kind}
                                </Badge>
                                <span className="text-xs text-slate-500">#{memory.id}</span>
                                {memory.archived && (
                                  <Badge variant="outline" className="text-xs">Archived</Badge>
                                )}
                              </div>
                              <p className="text-sm">{memory.canonical}</p>
                            </div>
                          </div>
                          <div className="flex gap-4 mt-2 text-xs text-slate-400">
                            <span className="flex items-center gap-1">
                              <TrendingUp className="w-3 h-3" />
                              {(memory.importance * 100).toFixed(0)}% imp
                            </span>
                            <span className="flex items-center gap-1">
                              <Target className="w-3 h-3" />
                              {(memory.stability * 100).toFixed(0)}% stab
                            </span>
                            <span className="flex items-center gap-1">
                              <Sparkles className="w-3 h-3" />
                              {(memory.novelty * 100).toFixed(0)}% nov
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {new Date(memory.ts).toLocaleTimeString()}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Search Tab */}
          <TabsContent value="search" className="space-y-4">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Search className="w-5 h-5 text-indigo-400" />
                  BM25 Search
                </CardTitle>
                <CardDescription>Search memories using BM25 algorithm with MMR diversification</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Enter search query..."
                    className="bg-slate-900 border-slate-600"
                    onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  />
                  <Button 
                    onClick={handleSearch} 
                    disabled={loading || !searchQuery.trim()}
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Search className="w-4 h-4 mr-2" />
                    Search
                  </Button>
                </div>

                {searchResults.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-slate-300">Results ({searchResults.length})</h4>
                    {searchResults.map((result) => (
                      <div 
                        key={result.id}
                        className="bg-slate-900/50 p-3 rounded-lg border border-slate-700"
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={`${kindColors[result.kind]} text-white text-xs`}>
                            {result.kind}
                          </Badge>
                          <span className="text-xs text-slate-500">Score: {result.score?.toFixed(3)}</span>
                        </div>
                        <p className="text-sm">{result.canonical}</p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Recall Tab */}
          <TabsContent value="recall" className="space-y-4">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Brain className="w-5 h-5 text-indigo-400" />
                  Associative Recall
                </CardTitle>
                <CardDescription>Recall memories using similarity, kind priority, and importance</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={recallQuery}
                    onChange={(e) => setRecallQuery(e.target.value)}
                    placeholder="Enter recall cue..."
                    className="bg-slate-900 border-slate-600"
                    onKeyDown={(e) => e.key === 'Enter' && handleRecall()}
                  />
                  <Button 
                    onClick={handleRecall} 
                    disabled={loading || !recallQuery.trim()}
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Brain className="w-4 h-4 mr-2" />
                    Recall
                  </Button>
                </div>

                {recallResults.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-slate-300">Recalled ({recallResults.length})</h4>
                    {recallResults.map((result) => (
                      <div 
                        key={result.id}
                        className="bg-slate-900/50 p-3 rounded-lg border border-slate-700"
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={`${kindColors[result.kind]} text-white text-xs`}>
                            {result.kind}
                          </Badge>
                          <span className="text-xs text-slate-500">Score: {result.score?.toFixed(3)}</span>
                        </div>
                        <p className="text-sm">{result.canonical}</p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Graph Tab */}
          <TabsContent value="graph" className="space-y-4">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Network className="w-5 h-5 text-indigo-400" />
                  Memory Graph
                </CardTitle>
                <CardDescription>Visualize memory connections via Lotus Cost paths</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={handleFetchGraph} 
                  disabled={loading}
                  className="bg-indigo-600 hover:bg-indigo-700"
                >
                  <Network className="w-4 h-4 mr-2" />
                  Load Graph
                </Button>

                {graph && (
                  <div className="bg-slate-900 rounded-lg p-2">
                    <canvas 
                      ref={canvasRef} 
                      width={800} 
                      height={500}
                      className="w-full h-auto rounded"
                    />
                    <div className="flex gap-4 mt-3 text-xs text-slate-400 justify-center">
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-full bg-blue-500"></span> Semantic
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-full bg-green-500"></span> State
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-full bg-amber-500"></span> Commitment
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-full bg-purple-500"></span> Episodic
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-full bg-red-500"></span> Hub
                      </span>
                    </div>
                    <p className="text-center text-xs text-slate-500 mt-2">
                      {graph.nodes.length} nodes, {graph.edges.length} edges
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              {/* Guard Query */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Shield className="w-5 h-5 text-indigo-400" />
                    FractalFinder Guard
                  </CardTitle>
                  <CardDescription>Analyze queries for potential security risks</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <Input
                      value={guardQuery}
                      onChange={(e) => setGuardQuery(e.target.value)}
                      placeholder="Enter query to analyze..."
                      className="bg-slate-900 border-slate-600"
                    />
                    <Button 
                      onClick={handleGuard} 
                      disabled={loading || !guardQuery.trim()}
                      className="bg-indigo-600 hover:bg-indigo-700"
                    >
                      <Shield className="w-4 h-4 mr-2" />
                      Analyze
                    </Button>
                  </div>

                  {guardResult && (
                    <Alert className={guardResult.safe ? 'border-green-500/50 bg-green-500/10' : 'border-red-500/50 bg-red-500/10'}>
                      {guardResult.safe ? (
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-red-500" />
                      )}
                      <AlertTitle>{guardResult.safe ? 'Safe' : 'Risk Detected'}</AlertTitle>
                      <AlertDescription>
                        <div className="mt-2 space-y-1">
                          <p>Risk Level: {(guardResult.risk * 100).toFixed(0)}%</p>
                          <Progress value={guardResult.risk * 100} className="h-2" />
                          <p className="text-sm">{guardResult.reason}</p>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>

              {/* Talos Check */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Activity className="w-5 h-5 text-indigo-400" />
                    Talos Drift Check
                  </CardTitle>
                  <CardDescription>Monitor system coherence and stability</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <Input
                      value={talosText}
                      onChange={(e) => setTalosText(e.target.value)}
                      placeholder="Enter text for drift analysis..."
                      className="bg-slate-900 border-slate-600"
                    />
                    <Button 
                      onClick={handleTalos} 
                      disabled={loading || !talosText.trim()}
                      className="bg-indigo-600 hover:bg-indigo-700"
                    >
                      <Activity className="w-4 h-4 mr-2" />
                      Check
                    </Button>
                  </div>

                  {talosResult && (
                    <Alert className={talosResult.stable ? 'border-green-500/50 bg-green-500/10' : 'border-amber-500/50 bg-amber-500/10'}>
                      {talosResult.stable ? (
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-amber-500" />
                      )}
                      <AlertTitle>{talosResult.stable ? 'Stable' : 'Drift Detected'}</AlertTitle>
                      <AlertDescription>
                        <div className="mt-2 space-y-2">
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div>
                              <span className="text-slate-400">Entropy:</span>
                              <span className="ml-2 font-mono">{talosResult.entropy.toFixed(3)}</span>
                            </div>
                            <div>
                              <span className="text-slate-400">Coherence:</span>
                              <span className="ml-2 font-mono">{talosResult.coherence.toFixed(3)}</span>
                            </div>
                          </div>
                          {talosResult.nudge && (
                            <p className="text-sm text-amber-400">
                              <Zap className="w-3 h-3 inline mr-1" />
                              Nudge suggestion: {talosResult.nudge}
                            </p>
                          )}
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Dream Tab */}
          <TabsContent value="dream" className="space-y-4">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Moon className="w-5 h-5 text-indigo-400" />
                  Dream Consolidation
                </CardTitle>
                <CardDescription>Consolidate unstable memories into hub summaries</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={handleDream} 
                  disabled={loading}
                  className="bg-indigo-600 hover:bg-indigo-700"
                >
                  <Moon className="w-4 h-4 mr-2" />
                  Dream Tick
                </Button>

                {dreamEvent && (
                  <Alert className="border-purple-500/50 bg-purple-500/10">
                    <Moon className="w-4 h-4 text-purple-400" />
                    <AlertTitle>Dream Event</AlertTitle>
                    <AlertDescription>
                      <div className="mt-2 space-y-2">
                        <p>{dreamEvent.message}</p>
                        {dreamEvent.reflect_hub !== null && (
                          <p className="text-sm text-purple-400">
                            Created hub #{dreamEvent.reflect_hub}
                          </p>
                        )}
                        {dreamEvent.archived_count > 0 && (
                          <p className="text-sm text-slate-400">
                            Archived {dreamEvent.archived_count} memories
                          </p>
                        )}
                      </div>
                    </AlertDescription>
                  </Alert>
                )}

                <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700">
                  <h4 className="text-sm font-medium mb-2">How Dreaming Works</h4>
                  <p className="text-sm text-slate-400">
                    The Dreamer identifies low-stability memories (stability &lt; 0.3) and consolidates them
                    into hub summaries. This mimics biological memory consolidation during sleep, where
                    unstable短期 memories are compressed into stable long-term representations.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Chat Tab */}
          <TabsContent value="chat" className="space-y-4">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <MessageCircle className="w-5 h-5 text-indigo-400" />
                  Cognitive Chat
                </CardTitle>
                <CardDescription>Chat with an LLM that has access to your cognitive memory system</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Local LLM Config */}
                <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700 mb-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Local LLM Configuration</span>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={useLocalLLM}
                        onCheckedChange={setUseLocalLLM}
                      />
                      <Label className="text-xs">Use Local LLM</Label>
                    </div>
                  </div>
                  {useLocalLLM && (
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      <Input
                        value={localLLMUrl}
                        onChange={(e) => setLocalLLMUrl(e.target.value)}
                        placeholder="http://localhost:11434/api/generate"
                        className="bg-slate-800 border-slate-600 text-xs h-7"
                      />
                      <Select value={localLLMModel} onValueChange={setLocalLLMModel}>
                        <SelectTrigger className="bg-slate-800 border-slate-600 h-7 text-xs">
                          <SelectValue placeholder="Select model" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="llama3.2">llama3.2</SelectItem>
                          <SelectItem value="llama3.1">llama3.1</SelectItem>
                          <SelectItem value="mistral">mistral</SelectItem>
                          <SelectItem value="codellama">codellama</SelectItem>
                          <SelectItem value="dolphin-mixtral">dolphin-mixtral</SelectItem>
                          <SelectItem value="custom">custom</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
                
                {/* Memory Info */}
                {lastChatInfo && (
                  <div className="flex gap-4 text-xs text-slate-400 bg-slate-900/50 p-2 rounded">
                    <span className="flex items-center gap-1">
                      <Brain className="w-3 h-3" />
                      {lastChatInfo.memoriesUsed} memories used
                    </span>
                    <span className="flex items-center gap-1">
                      <Plus className="w-3 h-3" />
                      {lastChatInfo.memoriesStored} memories stored
                    </span>
                  </div>
                )}

                {/* Chat Messages */}
                <div 
                  ref={chatScrollRef}
                  className="h-96 overflow-y-auto space-y-3 bg-slate-900/50 rounded-lg p-3 border border-slate-700"
                >
                  {chatMessages.length === 0 ? (
                    <div className="text-center text-slate-400 py-12">
                      <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Start a conversation with the cognitive AI.</p>
                      <p className="text-sm mt-2">It can recall memories and store new information.</p>
                    </div>
                  ) : (
                    chatMessages.map((msg, i) => (
                      <div 
                        key={i}
                        className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        {msg.role === 'assistant' && (
                          <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center flex-shrink-0">
                            <Bot className="w-4 h-4" />
                          </div>
                        )}
                        <div 
                          className={`max-w-[80%] p-3 rounded-lg ${
                            msg.role === 'user' 
                              ? 'bg-indigo-600 text-white' 
                              : 'bg-slate-800 border border-slate-700'
                          }`}
                        >
                          <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                        </div>
                        {msg.role === 'user' && (
                          <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center flex-shrink-0">
                            <User className="w-4 h-4" />
                          </div>
                        )}
                      </div>
                    ))
                  )}
                  {chatLoading && (
                    <div className="flex gap-3 justify-start">
                      <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center flex-shrink-0">
                        <Bot className="w-4 h-4" />
                      </div>
                      <div className="bg-slate-800 border border-slate-700 p-3 rounded-lg">
                        <div className="flex gap-1">
                          <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                          <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                          <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Chat Input */}
                <div className="flex gap-2">
                  <Input
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Type a message..."
                    className="bg-slate-900 border-slate-600"
                    onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleChat()}
                    disabled={chatLoading}
                  />
                  <Button 
                    onClick={handleChat} 
                    disabled={chatLoading || !chatInput.trim()}
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>

                {/* Tips */}
                <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700">
                  <h4 className="text-sm font-medium mb-2">Tips</h4>
                  <ul className="text-sm text-slate-400 space-y-1">
                    <li>• The AI can recall relevant memories before responding</li>
                    <li>• Share personal info and it will be stored as memories</li>
                    <li>• Try: &quot;My name is...&quot; or &quot;Remember that...&quot;</li>
                    <li>• Ask about topics you&apos;ve discussed before</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reference LLM Tab */}
          <TabsContent value="refllm" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              {/* Status Card */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Sparkles className="w-5 h-5 text-indigo-400" />
                    Reference LLM Status
                  </CardTitle>
                  <CardDescription>A living LLM that grows from accumulated knowledge</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {refLLMStatus ? (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Training Examples</span>
                          <div className="font-mono text-indigo-400 text-lg">{refLLMStatus.totalExamples}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Knowledge Entries</span>
                          <div className="font-mono text-indigo-400 text-lg">{refLLMStatus.totalKnowledge}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Est. Tokens</span>
                          <div className="font-mono text-indigo-400">{(refLLMStatus.estimatedTokens / 1000).toFixed(1)}k</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Metabolism Count</span>
                          <div className="font-mono text-indigo-400">{refLLMStatus.metabolismCount}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded col-span-2">
                          <span className="text-slate-400">Pending Examples</span>
                          <div className="font-mono text-amber-400">{refLLMStatus.pendingCount}</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${refLLMStatus.isActive ? 'bg-green-500' : 'bg-slate-500'}`}></div>
                        <span className="text-sm text-slate-400">
                          Auto-metabolism: {refLLMStatus.isActive ? 'Active (hourly)' : 'Inactive'}
                        </span>
                      </div>
                      
                      {refLLMStatus.lastMetabolism && (
                        <p className="text-xs text-slate-500">
                          Last metabolism: {new Date(refLLMStatus.lastMetabolism).toLocaleString()}
                        </p>
                      )}
                    </div>
                  ) : (
                    <p className="text-slate-400">Click refresh to load status</p>
                  )}
                  
                  <div className="flex gap-2 flex-wrap">
                    <Button 
                      onClick={() => { fetchRefLLMStatus(); fetchRefLLMKnowledge(); }} 
                      variant="outline"
                      size="sm"
                      className="border-slate-600"
                    >
                      <RefreshCw className="w-4 h-4 mr-1" />
                      Refresh
                    </Button>
                    <Button 
                      onClick={handleToggleAutoMetabolism} 
                      variant="outline"
                      size="sm"
                      className={refLLMStatus?.isActive ? 'border-red-500/50 text-red-400' : 'border-green-500/50 text-green-400'}
                    >
                      {refLLMStatus?.isActive ? 'Stop Auto' : 'Start Auto'}
                    </Button>
                    <Button 
                      onClick={handleMetabolism} 
                      size="sm"
                      className="bg-indigo-600 hover:bg-indigo-700"
                      disabled={loading}
                    >
                      <Zap className="w-4 h-4 mr-1" />
                      Metabolize Now
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Metabolism Result Card */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Activity className="w-5 h-5 text-indigo-400" />
                    Last Metabolism
                  </CardTitle>
                  <CardDescription>Results from knowledge processing cycle</CardDescription>
                </CardHeader>
                <CardContent>
                  {metabolismResult ? (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Processed</span>
                          <div className="font-mono text-green-400">{metabolismResult.processed}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">New Knowledge</span>
                          <div className="font-mono text-blue-400">{metabolismResult.newKnowledge}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Consolidated</span>
                          <div className="font-mono text-purple-400">{metabolismResult.consolidated}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Archived</span>
                          <div className="font-mono text-amber-400">{metabolismResult.archived}</div>
                        </div>
                      </div>
                      {metabolismResult.insights.length > 0 && (
                        <div className="mt-2">
                          <h4 className="text-sm font-medium mb-1">Insights:</h4>
                          <ul className="text-xs text-slate-400 space-y-1">
                            {metabolismResult.insights.map((insight, i) => (
                              <li key={i}>• {insight}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="text-slate-400">Run metabolism to see results</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Knowledge Base Card */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Brain className="w-5 h-5 text-indigo-400" />
                      Knowledge Base
                    </CardTitle>
                    <CardDescription>Accumulated wisdom from conversations and documents</CardDescription>
                  </div>
                  <Button 
                    onClick={handleExportRefLLM} 
                    variant="outline"
                    size="sm"
                    className="border-green-500/50 text-green-400"
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Export
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {refLLMKnowledge.length > 0 ? (
                  <div className="space-y-2 max-h-80 overflow-y-auto">
                    {refLLMKnowledge.map((entry) => (
                      <div key={entry.id} className="bg-slate-900/50 p-3 rounded-lg border border-slate-700">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium text-indigo-300">{entry.concept}</span>
                          <div className="flex gap-2 text-xs">
                            <span className="text-green-400">{(entry.confidence * 100).toFixed(0)}% conf</span>
                            <span className="text-slate-500">{entry.accessCount} uses</span>
                          </div>
                        </div>
                        <p className="text-sm text-slate-400">{entry.summary}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-slate-400 py-8">
                    <Brain className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>No knowledge entries yet. Start chatting to build knowledge!</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* How It Works */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-lg">How Reference LLM Works</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4 text-sm">
                  <div className="bg-slate-900/50 p-3 rounded-lg">
                    <div className="text-indigo-400 font-medium mb-1">1. Accumulate</div>
                    <p className="text-slate-400">Every conversation, import, and dream is stored as training data</p>
                  </div>
                  <div className="bg-slate-900/50 p-3 rounded-lg">
                    <div className="text-purple-400 font-medium mb-1">2. Metabolize</div>
                    <p className="text-slate-400">Hourly processing extracts knowledge from raw examples</p>
                  </div>
                  <div className="bg-slate-900/50 p-3 rounded-lg">
                    <div className="text-green-400 font-medium mb-1">3. Reference</div>
                    <p className="text-slate-400">Chat responses use accumulated knowledge for context</p>
                  </div>
                  <div className="bg-slate-900/50 p-3 rounded-lg">
                    <div className="text-amber-400 font-medium mb-1">4. Grow</div>
                    <p className="text-slate-400">Export training data for fine-tuning your own model</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Pulse Memory Tab */}
          <TabsContent value="pulse" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              {/* Status Card */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Zap className="w-5 h-5 text-indigo-400" />
                    Pulse Memory Status
                  </CardTitle>
                  <CardDescription>Geodesic traversal every 30 minutes</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {pulseStatus ? (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Pulse Count</span>
                          <div className="font-mono text-indigo-400 text-lg">{pulseStatus.pulseCount}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Nodes Visited</span>
                          <div className="font-mono text-indigo-400 text-lg">{pulseStatus.totalNodesVisited}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Insights Generated</span>
                          <div className="font-mono text-green-400 text-lg">{pulseStatus.totalInsights}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Paths Strengthened</span>
                          <div className="font-mono text-purple-400 text-lg">{pulseStatus.totalPathsStrengthened}</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${pulseStatus.isActive ? 'bg-green-500' : 'bg-slate-500'}`}></div>
                        <span className="text-sm text-slate-400">
                          Auto-pulse: {pulseStatus.isActive ? 'Active (30 min)' : 'Inactive'}
                        </span>
                      </div>
                      
                      {pulseStatus.lastPulse && (
                        <p className="text-xs text-slate-500">
                          Last pulse: {new Date(pulseStatus.lastPulse).toLocaleString()}
                        </p>
                      )}
                      
                      {storeInfo && (
                        <div className="flex gap-4 text-xs text-slate-500">
                          <span>Memories: {storeInfo.roomCount}</span>
                          <span>Edges: {storeInfo.graphEdges}</span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="text-slate-400">Click refresh to load status</p>
                  )}
                  
                  <div className="flex gap-2 flex-wrap">
                    <Button 
                      onClick={fetchPulseStatus} 
                      variant="outline"
                      size="sm"
                      className="border-slate-600"
                    >
                      <RefreshCw className="w-4 h-4 mr-1" />
                      Refresh
                    </Button>
                    <Button 
                      onClick={handleToggleAutoPulse} 
                      variant="outline"
                      size="sm"
                      className={pulseStatus?.isActive ? 'border-red-500/50 text-red-400' : 'border-green-500/50 text-green-400'}
                    >
                      {pulseStatus?.isActive ? 'Stop Auto' : 'Start Auto'}
                    </Button>
                    <Button 
                      onClick={handlePulse} 
                      size="sm"
                      className="bg-indigo-600 hover:bg-indigo-700"
                      disabled={loading}
                    >
                      <Zap className="w-4 h-4 mr-1" />
                      Pulse Now
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Pulse Result Card */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Activity className="w-5 h-5 text-indigo-400" />
                    Last Pulse Result
                  </CardTitle>
                  <CardDescription>Geodesic path traversal results</CardDescription>
                </CardHeader>
                <CardContent>
                  {pulseResult ? (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Coverage</span>
                          <div className="font-mono text-green-400">{pulseResult.path?.coverage?.toFixed(0)}%</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Duration</span>
                          <div className="font-mono text-blue-400">{pulseResult.duration}ms</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Path Strength</span>
                          <div className="font-mono text-purple-400">{pulseResult.path?.pathStrength?.toFixed(3)}</div>
                        </div>
                        <div className="bg-slate-900/50 p-2 rounded">
                          <span className="text-slate-400">Total Cost</span>
                          <div className="font-mono text-amber-400">{pulseResult.path?.totalCost?.toFixed(3)}</div>
                        </div>
                      </div>
                      
                      <div>
                        <span className="text-sm text-slate-400">Path: </span>
                        <span className="text-xs font-mono text-slate-300">
                          {pulseResult.path?.nodeIds?.slice(0, 8).join(' → ')}
                          {pulseResult.path?.nodeIds && pulseResult.path.nodeIds.length > 8 && ' ...'}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <p className="text-slate-400">Execute a pulse to see results</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Insights Card */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Sparkles className="w-5 h-5 text-indigo-400" />
                  Pulse Insights
                </CardTitle>
                <CardDescription>Generated insights from geodesic traversal</CardDescription>
              </CardHeader>
              <CardContent>
                {pulseResult?.insights && pulseResult.insights.length > 0 ? (
                  <div className="space-y-2">
                    {pulseResult.insights.map((insight, i) => (
                      <div key={i} className="bg-slate-900/50 p-3 rounded-lg border border-slate-700">
                        <p className="text-sm text-slate-300">{insight}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-slate-400 py-8">
                    <Sparkles className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>Run a pulse to generate insights from memory traversal</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* How It Works */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-lg">How Pulse Memory Works</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4 text-sm">
                  <div className="bg-slate-900/50 p-3 rounded-lg">
                    <div className="text-indigo-400 font-medium mb-1">1. Geodesic Path</div>
                    <p className="text-slate-400">Traverse ALL memory nodes via Lotus Cost optimized Hamiltonian path</p>
                  </div>
                  <div className="bg-slate-900/50 p-3 rounded-lg">
                    <div className="text-purple-400 font-medium mb-1">2. Dream Phase</div>
                    <p className="text-slate-400">30-second insight generation with entropy & pattern analysis</p>
                  </div>
                  <div className="bg-slate-900/50 p-3 rounded-lg">
                    <div className="text-green-400 font-medium mb-1">3. Strengthen</div>
                    <p className="text-slate-400">Neural paths strengthened, never deleted - additive growth</p>
                  </div>
                  <div className="bg-slate-900/50 p-3 rounded-lg">
                    <div className="text-amber-400 font-medium mb-1">4. Store</div>
                    <p className="text-slate-400">Insights saved as semantic memories for future reference</p>
                  </div>
                </div>
                
                <div className="mt-4 p-3 bg-slate-900/30 rounded-lg border border-slate-700">
                  <h4 className="text-sm font-medium mb-2 text-indigo-300">Key Formulas:</h4>
                  <ul className="text-xs text-slate-400 space-y-1">
                    <li>• Lotus Cost: dist + λ_π·π + μ_risk·risk + singularity(σ)</li>
                    <li>• Path Strength: S(p) = Σ(stability × importance × (1 + 0.5×novelty))</li>
                    <li>• Strengthening: ΔS = 5% + 25% × (0.7×stability + 0.3×importance)</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Code Tab */}
          <TabsContent value="code" className="space-y-4">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Code className="w-5 h-5 text-indigo-400" />
                  Code Repository
                </CardTitle>
                <CardDescription>View the source code that powers the cognitive architecture</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Button 
                    onClick={handleFetchCode} 
                    disabled={loading}
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <FileJson className="w-4 h-4 mr-2" />
                    Load Code
                  </Button>
                  {selectedFile && (
                    <Button 
                      onClick={handleCopyCode} 
                      variant="outline"
                      className="border-slate-600"
                    >
                      {copiedFile ? (
                        <>
                          <Check className="w-4 h-4 mr-2 text-green-400" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copy
                        </>
                      )}
                    </Button>
                  )}
                </div>

                {Object.keys(codeFiles).length > 0 && (
                  <div className="space-y-4">
                    {/* File selector */}
                    <div className="flex flex-wrap gap-2">
                      {Object.keys(codeFiles).map((file) => (
                        <Button
                          key={file}
                          onClick={() => setSelectedFile(file)}
                          variant={selectedFile === file ? "default" : "outline"}
                          size="sm"
                          className={selectedFile === file ? "bg-indigo-600" : "border-slate-600"}
                        >
                          {file.split('/').pop()}
                        </Button>
                      ))}
                    </div>

                    {/* Code display */}
                    {selectedFile && (
                      <div className="bg-slate-900 rounded-lg border border-slate-700 overflow-hidden">
                        <div className="bg-slate-800 px-4 py-2 border-b border-slate-700 flex items-center justify-between">
                          <span className="text-sm text-slate-400">{selectedFile}</span>
                          <span className="text-xs text-slate-500">
                            {codeFiles[selectedFile].split('\n').length} lines
                          </span>
                        </div>
                        <ScrollArea className="h-[500px]">
                          <pre className="p-4 text-sm text-slate-300 overflow-x-auto">
                            <code>{codeFiles[selectedFile]}</code>
                          </pre>
                        </ScrollArea>
                      </div>
                    )}
                  </div>
                )}

                {Object.keys(codeFiles).length === 0 && (
                  <div className="text-center text-slate-400 py-12">
                    <Code className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>Click &quot;Load Code&quot; to view the source files</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
