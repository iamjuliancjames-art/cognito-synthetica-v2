import { NextRequest, NextResponse } from 'next/server';
import { getReferenceLLM } from '@/lib/cognito/reference-llm';
import { getLLMMemory } from '@/lib/cognito/llm-memory';

// GET endpoints for status and data
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action');

  try {
    switch (action) {
      case 'status': {
        const refLLM = getReferenceLLM();
        const llmMemory = getLLMMemory();
        const state = llmMemory.getState();
        const status = refLLM.getStatus();

        return NextResponse.json({
          success: true,
          status: {
            ...status,
            totalExamples: state.totalExamples,
            totalKnowledge: state.knowledgeBase.length,
            estimatedTokens: state.totalTokens,
            metabolismCount: state.metabolismCount,
            pendingCount: llmMemory.getPendingCount(),
            version: state.version,
            createdAt: state.createdAt,
          },
        });
      }

      case 'knowledge': {
        const llmMemory = getLLMMemory();
        const knowledge = llmMemory.getKnowledgeBase();
        const limit = parseInt(searchParams.get('limit') || '50');

        return NextResponse.json({
          success: true,
          knowledge: knowledge.slice(0, limit),
          total: knowledge.length,
        });
      }

      case 'training_data': {
        const refLLM = getReferenceLLM();
        const data = refLLM.getTrainingData();

        return NextResponse.json({
          success: true,
          stats: data.stats,
          examplesCount: data.examples.length,
          knowledgeCount: data.knowledge.length,
        });
      }

      case 'export': {
        const refLLM = getReferenceLLM();
        const exportData = refLLM.exportKnowledge();

        return NextResponse.json({
          success: true,
          data: JSON.parse(exportData),
        });
      }

      case 'export_jsonl': {
        const llmMemory = getLLMMemory();
        const jsonl = llmMemory.getTrainingDataJSONL();

        return new NextResponse(jsonl, {
          headers: {
            'Content-Type': 'application/x-jsonlines',
            'Content-Disposition': 'attachment; filename="llm-training-data.jsonl"',
          },
        });
      }

      case 'search_knowledge': {
        const query = searchParams.get('query') || '';
        const limit = parseInt(searchParams.get('limit') || '10');
        const llmMemory = getLLMMemory();
        const results = llmMemory.searchKnowledge(query, limit);

        return NextResponse.json({
          success: true,
          results,
          query,
        });
      }

      default:
        return NextResponse.json({
          success: false,
          error: 'Unknown action. Use: status, knowledge, training_data, export, export_jsonl, search_knowledge',
        }, { status: 400 });
    }
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }, { status: 500 });
  }
}

// POST endpoints for actions
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    switch (action) {
      case 'metabolize': {
        const refLLM = getReferenceLLM();
        const result = await refLLM.runMetabolism();

        return NextResponse.json({
          success: result.success,
          result: result.result,
          error: result.error,
        });
      }

      case 'start_auto': {
        const refLLM = getReferenceLLM();
        const interval = body.intervalMinutes ? body.intervalMinutes * 60 * 1000 : undefined;
        
        if (interval) {
          refLLM.updateConfig({});
        }
        
        refLLM.startAutoMetabolism();

        return NextResponse.json({
          success: true,
          message: 'Auto-metabolism started (hourly)',
        });
      }

      case 'stop_auto': {
        const refLLM = getReferenceLLM();
        refLLM.stopAutoMetabolism();

        return NextResponse.json({
          success: true,
          message: 'Auto-metabolism stopped',
        });
      }

      case 'import': {
        const { data } = body;
        if (!data) {
          return NextResponse.json({
            success: false,
            error: 'Data is required for import',
          }, { status: 400 });
        }

        const refLLM = getReferenceLLM();
        refLLM.importKnowledge(JSON.stringify(data));

        return NextResponse.json({
          success: true,
          message: 'Knowledge imported successfully',
        });
      }

      case 'reset': {
        const refLLM = getReferenceLLM();
        refLLM.reset();

        return NextResponse.json({
          success: true,
          message: 'Reference LLM reset',
        });
      }

      case 'add_knowledge': {
        const { concept, summary, importance = 0.8 } = body;
        if (!concept || !summary) {
          return NextResponse.json({
            success: false,
            error: 'Concept and summary are required',
          }, { status: 400 });
        }

        const llmMemory = getLLMMemory();
        llmMemory.addReflection(concept, summary, { manual: true });

        return NextResponse.json({
          success: true,
          message: 'Knowledge added',
        });
      }

      case 'update_config': {
        const { config } = body;
        const refLLM = getReferenceLLM();
        refLLM.updateConfig(config);

        return NextResponse.json({
          success: true,
          message: 'Config updated',
          config: refLLM.getStatus().config,
        });
      }

      default:
        return NextResponse.json({
          success: false,
          error: 'Unknown action. Use: metabolize, start_auto, stop_auto, import, reset, add_knowledge, update_config',
        }, { status: 400 });
    }
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }, { status: 500 });
  }
}
