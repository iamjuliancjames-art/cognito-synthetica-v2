import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { getCognitoInstance } from '../cognito/route';
import { getLLMMemory } from '@/lib/cognito/llm-memory';
import { getReferenceLLM } from '@/lib/cognito/reference-llm';
import { getLocalLLM } from '@/lib/cognito/local-llm';
import { initGeodesicRetrieval, getGeodesicRetrieval, GeodesicRetrieval } from '@/lib/cognito/geodesic-retrieval';

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

// System prompt that instructs the LLM how to use cognitive memory
const COGNITIVE_SYSTEM_PROMPT = `You are an AI assistant with a sophisticated cognitive memory system called Cognito Synthetica. You have persistent, associative memory that helps you remember important information across conversations.

MEMORY SYSTEM CAPABILITIES:
- All conversations are automatically stored as memories
- You can recall relevant memories using associative cues
- Your memories are connected in a graph, allowing you to find related information
- You can search your memories using keywords
- Uploaded documents (PDFs, text files) are stored as memories you can reference

MEMORY TYPES (kinds):
- "semantic": General knowledge and facts
- "episodic": Events, experiences, and conversations
- "state": Current states and conditions
- "commitment": Important promises and commitments to remember
- "page": Documents and uploaded files

HOW TO USE MEMORY:
When you want to explicitly store something important, use this format in your response:
[MEMORY: kind=semantic] Important fact to remember [/MEMORY]

When responding to users:
1. Consider what memories might be relevant
2. Reference past information when appropriate
3. Store new important information the user shares
4. Reference uploaded documents when asked about them
5. Be helpful and conversational

META-COGNITIVE CAPABILITIES:
When users ask about your memories, memory graph, or how to improve your memory system, you can analyze and provide insights. You can:
- Describe what types of memories you have
- Suggest improvements to memory organization
- Reflect on memory patterns and connections
- Identify gaps or areas for improvement

You have access to recalled memories in your context. Use them naturally in conversation. Don't mention the memory system explicitly unless the user asks about it.`;

// Meta-cognitive prompt for self-reflection
const META_COGNITIVE_PROMPT = `You are analyzing your own cognitive memory system. Based on the memories provided, offer thoughtful insights about:

1. MEMORY ANALYSIS: What types of memories do you have? What themes emerge?
2. CONNECTIONS: How are memories connected? What patterns exist?
3. IMPROVEMENTS: What could make the memory system better? What's missing?
4. RECOMMENDATIONS: Specific suggestions for better memory organization or recall

Be introspective and helpful. Treat this as an opportunity to improve your cognitive architecture.`;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { messages, autoMemory = true, useLocalLLM = false, localLLMUrl = '', localLLMModel = '' } = body;

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json({
        success: false,
        error: 'Messages array is required',
      }, { status: 400 });
    }

    const cs = getCognitoInstance();

    // ============================================================
    // MEMORY CONTEXT GATHERING
    // ============================================================

    // Step 1: Extract the latest user message
    const latestUserMessage = messages.filter((m: ChatMessage) => m.role === 'user').pop();
    const userContent = latestUserMessage?.content || '';
    const userContentLower = userContent.toLowerCase();

    // Detect meta-cognitive queries
    const isMetaCognitiveQuery =
      userContentLower.includes('your memories') ||
      userContentLower.includes('your memory') ||
      userContentLower.includes('how to improve') && (userContentLower.includes('memory') || userContentLower.includes('graph')) ||
      userContentLower.includes('memory graph') ||
      userContentLower.includes('analyze your') ||
      userContentLower.includes('reflect on your') ||
      userContentLower.includes('what do you remember') ||
      userContentLower.includes('what have you learned') ||
      userContentLower.includes('tell me about yourself') ||
      userContentLower.includes('your cognitive') ||
      userContentLower.includes('self-improvement');

    // Detect document-related queries
    const isDocumentQuery =
      userContentLower.includes('pdf') ||
      userContentLower.includes('document') ||
      userContentLower.includes('uploaded file') ||
      userContentLower.includes('the file') ||
      userContentLower.includes('the document');

    // ============================================================
    // GEODESIC BEST FIT RETRIEVAL - O(k log n) instead of O(n)
    // ============================================================
    
    // Initialize geodesic retrieval (uses cached priority nodes)
    let geoRetrieval: GeodesicRetrieval;
    try {
      geoRetrieval = getGeodesicRetrieval();
    } catch {
      geoRetrieval = initGeodesicRetrieval(cs.getStore(), cs.getTuning(), {
        maxPathLength: 6,
        minScore: 0.18,
        earlyTermination: true,
        diversityFactor: 0.7,
        priorityBoost: 1.4,
      });
    }

    // Multi-vector geodesic best fit retrieval
    const geoResults = geoRetrieval.geodesicBestFit(userContent, 8, 4);

    // Convert to memory context format with rich metadata
    const memoryContext: string[] = [];
    const seenIds = new Set<number>();

    for (const result of geoResults) {
      if (!seenIds.has(result.room.id)) {
        seenIds.add(result.room.id);
        const kind = result.room.meta.kind;
        const scoreInfo = `(geo-score: ${result.score.toFixed(2)}, path: ${result.pathLength}hops)`;
        
        // Include document metadata for page-type memories
        if (kind === 'page' && result.room.fields.filename) {
          memoryContext.push(`[${kind}] ${scoreInfo} (Document: ${result.room.fields.filename}) ${result.room.canonical}`);
        } else {
          memoryContext.push(`[${kind}] ${scoreInfo} ${result.room.canonical}`);
        }
      }
    }

    // For meta-cognitive queries, get a broader sample of memories
    if (isMetaCognitiveQuery) {
      const allMemories = cs.getStore().getAllRooms();
      const memorySample = allMemories.slice(0, 20);
      memoryContext.length = 0; // Clear for meta-cognitive sample
      for (const room of memorySample) {
        memoryContext.push(`[${room.meta.kind}] ${room.canonical}`);
      }
    }

    // For document queries, add more document-specific results
    if (isDocumentQuery) {
      const docResults = geoRetrieval.geodesicBestFit('document PDF uploaded file content', 5, 3);
      for (const result of docResults) {
        if (!seenIds.has(result.room.id) && result.room.meta.kind === 'page') {
          seenIds.add(result.room.id);
          memoryContext.unshift(`[page] (Document) ${result.room.canonical}`);
        }
      }
    }

    // Step 3: Build context with memories
    let memoryContextStr = memoryContext.length > 0
      ? `\n\nRELEVANT MEMORIES:\n${memoryContext.map(m => `- ${m}`).join('\n')}`
      : '\n\nRELEVANT MEMORIES: None yet.';

    // Step 4: Prepare messages for LLM
    let systemPrompt = COGNITIVE_SYSTEM_PROMPT;

    // For meta-cognitive queries, enhance the system prompt
    if (isMetaCognitiveQuery) {
      systemPrompt = COGNITIVE_SYSTEM_PROMPT + '\n\n' + META_COGNITIVE_PROMPT;

      // Add memory statistics
      const allMemories = cs.getStore().getAllRooms();
      const kindCounts: Record<string, number> = {};
      for (const m of allMemories) {
        kindCounts[m.meta.kind] = (kindCounts[m.meta.kind] || 0) + 1;
      }

      const graphStats = {
        nodes: allMemories.length,
        edges: Array.from(cs.getStore().graph.values()).reduce((sum, m) => sum + m.size, 0) / 2,
      };

      memoryContextStr += `\n\nMEMORY STATISTICS:\n- Total memories: ${allMemories.length}\n- Memory types: ${JSON.stringify(kindCounts)}\n- Graph connections: ${Math.floor(graphStats.edges)}\n- Anchors: ${cs.getStore().anchorIds.size}\n- Attractors: ${cs.getStore().attractors.length}`;
    }

    
    const systemMessage = {
      role: 'system' as const,
      content: systemPrompt + memoryContextStr,
    };

    
    const messagesForLLM = [systemMessage, ...messages];

    // ============================================================
    // LLM CALL - Local or Cloud
    // ============================================================
    
    let assistantResponse: string;
    const temperature = 0.7;
    const maxTokens = 1024;
    
    if (useLocalLLM) {
      // Use local LLM (LM Studio / Ollama)
      const localLLM = getLocalLLM({
        type: 'openai-compatible',
        baseUrl: localLLMUrl || 'http://localhost:1234',
        model: localLLMModel || 'gemma-3',
      });
      
      const response = await localLLM.chat(messagesForLLM);
      assistantResponse = response.content;
    } else {
      // Use cloud API
      const zai = await ZAI.create();
      const completion = await zai.chat.completions.create({
        messages: messagesForLLM,
        temperature,
        max_tokens: maxTokens,
      });
      assistantResponse = completion.choices[0]?.message?.content || '';
    }
    
    // ============================================================
    // MEMORY STORAGE
    // ============================================================
    
    const storedMemories: string[] = [];

    if (autoMemory) {
      // 1. Store user's message
      if (userContent.trim().length > 0) {
        const conversationMemory = `User said: "${userContent.trim()}"`;
        cs.addMemory(conversationMemory, 'episodic', false, false);
        storedMemories.push(`[episodic] ${conversationMemory.slice(0, 80)}...`);
      }

      // 2. Extract MEMORY tags from response
      const memoryMatches = assistantResponse.match(/\[MEMORY:\s*kind=(\w+)\]\s*([^[]+)\s*\[\/MEMORY\]/gi);
      if (memoryMatches) {
        for (const match of memoryMatches) {
          const kindMatch = match.match(/kind=(\w+)/i);
          const contentMatch = match.match(/\]\s*([^[]+)\s*\[/);

          if (kindMatch && contentMatch) {
            const kind = kindMatch[1].toLowerCase();
            const content = contentMatch[1].trim();
            cs.addMemory(content, kind, false, false);
            storedMemories.push(`[${kind}] ${content}`);
          }
        }
      }

      // 3. Store assistant's response
      const cleanResponseForMemory = assistantResponse
        .replace(/\[MEMORY:[^\]]+\][^[]+\[\/MEMORY\]/gi, '')
        .trim();
      
      if (cleanResponseForMemory.length > 10) {
        const assistantMemory = `Assistant responded: "${cleanResponseForMemory.slice(0, 200)}${cleanResponseForMemory.length > 200 ? '...' : ''}"`;
        cs.addMemory(assistantMemory, 'episodic', false, false);
        storedMemories.push(`[episodic] Assistant response stored`);
      }

      // 4. Extract facts from user message
      if (userContent.length > 10) {
        const factPatterns = [
          { pattern: /my name is (\w+)/i, prefix: "User's name is" },
          { pattern: /i am (?:a|an) (.+?)(?:\.|,|$)/i, prefix: "User is" },
          { pattern: /i work (?:as|at|with) (.+?)(?:\.|,|$)/i, prefix: "User works" },
          { pattern: /i live in (.+?)(?:\.|,|$)/i, prefix: "User lives in" },
          { pattern: /i like (.+?)(?:\.|,|$)/i, prefix: "User likes" },
          { pattern: /i love (.+?)(?:\.|,|$)/i, prefix: "User loves" },
          { pattern: /i hate (.+?)(?:\.|,|$)/i, prefix: "User dislikes" },
          { pattern: /my favorite (.+?) is (.+?)(?:\.|,|$)/i, prefix: "User's favorite" },
          { pattern: /remember (?:that )?(.+?)(?:\.|,|$)/i, prefix: "Important:" },
          { pattern: /don't forget (?:that )?(.+?)(?:\.|,|$)/i, prefix: "Remember:" },
          { pattern: /i want to (.+?)(?:\.|,|$)/i, prefix: "User wants to" },
          { pattern: /i need (.+?)(?:\.|,|$)/i, prefix: "User needs" },
          { pattern: /my goal is (.+?)(?:\.|,|$)/i, prefix: "User's goal:" },
        ];

        for (const { pattern, prefix } of factPatterns) {
          const match = userContent.match(pattern);
          if (match) {
            const extractedInfo = match[1]?.trim() || match.slice(1).filter(Boolean).join(' ');
            if (extractedInfo && extractedInfo.length > 2 && extractedInfo.length < 150) {
              const existingMemories = cs.recall(extractedInfo, 1, 0.85);
              if (existingMemories.length === 0) {
                const factMemory = `${prefix} ${extractedInfo}`;
                cs.addMemory(factMemory, 'semantic', false, false);
                storedMemories.push(`[semantic] ${factMemory}`);
              }
            }
          }
        }

        // 5. Detect questions
        if (userContent.includes('?')) {
          const questionMatch = userContent.match(/^(?:what|how|why|when|where|who|can you|could you|would you)/i);
          if (questionMatch) {
            const interestMemory = `User asked about: ${userContent.slice(0, 100)}`;
            cs.addMemory(interestMemory, 'episodic', false, false);
            storedMemories.push(`[episodic] Question recorded`);
          }
        }

        // 6. Detect commitments
        const commitmentPatterns = [
          /i will (.+?)(?:\.|,|$)/i,
          /i'll (.+?)(?:\.|,|$)/i,
          /i can help you (.+?)(?:\.|,|$)/i,
          /let me (.+?)(?:\.|,|$)/i,
        ];

        for (const pattern of commitmentPatterns) {
          const match = cleanResponseForMemory.match(pattern);
          if (match) {
            const commitment = match[1]?.trim();
            if (commitment && commitment.length > 5) {
              cs.addMemory(`Assistant committed to: ${commitment}`, 'commitment', false, false);
              storedMemories.push(`[commitment] ${commitment.slice(0, 50)}...`);
            }
          }
        }
      }
    }

    // Clean response
    const cleanResponse = assistantResponse.replace(/\[MEMORY:[^\]]+\][^[]+\[\/MEMORY\]/gi, '').trim();

    // Security check
    const guardResult = cs.guardQuery(userContent);
    
    // Store in LLM Memory
    const llmMemory = getLLMMemory();
    llmMemory.addConversation(
      userContent,
      cleanResponse,
      memoryContext.length,
      storedMemories.length
    );
    
    if (isMetaCognitiveQuery && cleanResponse.length > 100) {
      llmMemory.addReflection(userContent, cleanResponse, {
        memoryCount: memoryContext.length,
        type: 'meta_cognitive',
      });
    }
    
    const pendingCount = llmMemory.getPendingCount();

    return NextResponse.json({
      success: true,
      response: cleanResponse,
      memories_used: memoryContext.length,
      memories_stored: storedMemories.length,
      stored_memories: storedMemories,
      security: {
        risk: guardResult.risk,
        safe: guardResult.safe,
      },
      llm_memory: {
        pending_count: pendingCount,
        metabolism_recommended: pendingCount >= 10,
        total_examples: llmMemory.getState().totalExamples,
      },
    });

  } catch (error) {
    console.error('Chat error:', error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }, { status: 500 });
  }
}

// GET endpoint
export async function GET() {
  try {
    const cs = getCognitoInstance();
    const localLLM = getLocalLLM();

    return NextResponse.json({
      success: true,
      status: cs.status(),
      memory_count: cs.getStore().getRoomCount(),
      local_llm: {
        available: await localLLM.isAvailable(),
        config: localLLM.getConfig(),
      },
      message: 'Cognitive LLM chat endpoint ready',
    });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }, { status: 500 });
  }
}
