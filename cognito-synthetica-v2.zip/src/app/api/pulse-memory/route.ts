import { NextRequest, NextResponse } from 'next/server';
import { getCognitoInstance } from '../cognito/route';
import { getPulseMemory } from '@/lib/cognito/pulse-memory';
import { getLLMMemory } from '@/lib/cognito/llm-memory';

// GET endpoints
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action');

  try {
    const cognito = getCognitoInstance();
    const store = cognito.getStore();
    
    // Debug: Log store state
    console.log('[PulseMemory API] Store rooms:', store.getAllRooms().length);
    
    const pulseMemory = getPulseMemory(store, cognito.getTuning());

    switch (action) {
      case 'status': {
        const status = pulseMemory.getStatus();
        const storeStatus = {
          roomCount: store.getAllRooms().length,
          graphEdges: Array.from(store.graph.values()).reduce((sum, m) => sum + m.size, 0),
        };
        return NextResponse.json({
          success: true,
          ...status,
          store: storeStatus,
        });
      }

      case 'strengthening': {
        const recent = pulseMemory.getRecentStrengthening();
        return NextResponse.json({
          success: true,
          strengthening: recent,
          count: recent.length,
        });
      }

      case 'state': {
        const state = pulseMemory.getState();
        return NextResponse.json({
          success: true,
          state,
        });
      }
      
      case 'path': {
        // Generate a geodesic path without executing pulse
        const path = pulseMemory.createGeodesicPath();
        return NextResponse.json({
          success: true,
          path,
          nodesVisited: path.nodeIds.length,
          coverage: path.coverage,
          insights: path.insights,
        });
      }

      default:
        return NextResponse.json({
          success: false,
          error: 'Unknown action. Use: status, strengthening, state, path',
        }, { status: 400 });
    }
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }, { status: 500 });
  }
}

// POST endpoints
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;
    
    const cognito = getCognitoInstance();
    const store = cognito.getStore();
    const pulseMemory = getPulseMemory(store, cognito.getTuning());
    const llmMemory = getLLMMemory();

    switch (action) {
      case 'pulse': {
        // Execute a single pulse manually
        const result = await pulseMemory.pulse();
        
        // Store insights in LLM memory for the reference LLM
        if (result.success && result.insights.length > 0) {
          llmMemory.addReflection(
            'Pulse memory geodesic traversal',
            result.insights.join('\n'),
            { 
              nodesVisited: result.nodesVisited,
              pathsStrengthened: result.pathsStrengthened,
            }
          );
        }
        
        return NextResponse.json({
          success: result.success,
          result,
        });
      }

      case 'start_auto': {
        pulseMemory.startAutoPulse();
        return NextResponse.json({
          success: true,
          message: 'Auto-pulse started (every 30 minutes)',
          status: pulseMemory.getStatus(),
        });
      }

      case 'stop_auto': {
        pulseMemory.stopAutoPulse();
        return NextResponse.json({
          success: true,
          message: 'Auto-pulse stopped',
          status: pulseMemory.getStatus(),
        });
      }

      case 'reset': {
        pulseMemory.reset();
        return NextResponse.json({
          success: true,
          message: 'Pulse memory reset',
        });
      }

      default:
        return NextResponse.json({
          success: false,
          error: 'Unknown action. Use: pulse, start_auto, stop_auto, reset',
        }, { status: 400 });
    }
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }, { status: 500 });
  }
}
