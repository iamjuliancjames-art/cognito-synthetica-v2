import { NextRequest, NextResponse } from 'next/server';
import { TUNING_LEVELS } from '@/lib/cognito/engine';
import { getCognitoInstance, resetSharedState, getSharedStore } from '@/lib/cognito/shared-state';
import { initGeodesicRetrieval, getGeodesicRetrieval } from '@/lib/cognito/geodesic-retrieval';
import { PDFParse } from 'pdf-parse';

// Helper function to split text into chunks
function splitTextIntoChunks(text: string, maxChunkSize: number = 1000): string[] {
  const chunks: string[] = [];
  const paragraphs = text.split(/\n\n+/);
  let currentChunk = '';
  
  for (const paragraph of paragraphs) {
    if ((currentChunk + paragraph).length > maxChunkSize && currentChunk.length > 0) {
      chunks.push(currentChunk.trim());
      currentChunk = paragraph;
    } else {
      currentChunk += '\n\n' + paragraph;
    }
  }
  
  if (currentChunk.trim().length > 0) {
    chunks.push(currentChunk.trim());
  }
  
  return chunks.filter(c => c.length > 50); // Filter out very short chunks
}

// Re-export for backward compatibility with other routes
export { getCognitoInstance } from '@/lib/cognito/shared-state';

// Get cognito instance for use in this file
const getCognito = getCognitoInstance;

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action');

  const cs = getCognito();

  try {
    switch (action) {
      case 'status': {
        return NextResponse.json({
          success: true,
          status: cs.status(),
          tuning: cs.getTuning(),
        });
      }

      case 'search': {
        const query = searchParams.get('query') || '';
        const topK = parseInt(searchParams.get('topK') || '6');
        const hops = parseInt(searchParams.get('hops') || '2');
        const diversify = searchParams.get('diversify') !== 'false';

        const results = cs.search(query, topK, hops, diversify);
        return NextResponse.json({
          success: true,
          results: results.map(r => ({
            id: r.room.id,
            canonical: r.room.canonical,
            kind: r.room.meta.kind,
            score: r.score,
            importance: r.room.meta.importance,
            stability: r.room.meta.stability,
            novelty: r.room.meta.novelty,
            ts: r.room.meta.ts,
          })),
        });
      }

      case 'recall': {
        const query = searchParams.get('query') || '';
        const topK = parseInt(searchParams.get('topK') || '6');

        const results = cs.recall(query, topK);
        return NextResponse.json({
          success: true,
          results: results.map(r => ({
            id: r.room.id,
            canonical: r.room.canonical,
            kind: r.room.meta.kind,
            score: r.score,
            importance: r.room.meta.importance,
            stability: r.room.meta.stability,
            novelty: r.room.meta.novelty,
            ts: r.room.meta.ts,
          })),
        });
      }

      case 'tick': {
        const event = cs.tick();
        return NextResponse.json({
          success: true,
          event,
        });
      }

      case 'guard': {
        const query = searchParams.get('query') || '';
        const result = cs.guardQuery(query);
        return NextResponse.json({
          success: true,
          guard: result,
        });
      }

      case 'talos': {
        const text = searchParams.get('text') || '';
        const result = cs.talosCheck(text);
        return NextResponse.json({
          success: true,
          talos: result,
        });
      }

      case 'graph': {
        const store = cs.getStore();
        const nodes: Array<{ id: number; label: string; kind: string }> = [];
        const edges: Array<{ source: number; target: number; weight: number }> = [];

        // Get all rooms as nodes
        for (const room of store.getAllRooms()) {
          nodes.push({
            id: room.id,
            label: room.canonical.slice(0, 30) + (room.canonical.length > 30 ? '...' : ''),
            kind: room.meta.kind,
          });
        }

        // Get all edges
        const seenEdges = new Set<string>();
        for (const [source, neighbors] of store.graph) {
          for (const [target, weight] of neighbors) {
            const key = [Math.min(source, target), Math.max(source, target)].join('-');
            if (!seenEdges.has(key)) {
              seenEdges.add(key);
              edges.push({ source, target, weight });
            }
          }
        }

        return NextResponse.json({
          success: true,
          graph: { nodes, edges },
        });
      }

      case 'memories': {
        const store = cs.getStore();
        const memories = store.getAllRooms().map(room => ({
          id: room.id,
          canonical: room.canonical,
          kind: room.meta.kind,
          importance: room.meta.importance,
          stability: room.meta.stability,
          novelty: room.meta.novelty,
          archived: room.meta.archived,
          ts: room.meta.ts,
        }));

        return NextResponse.json({
          success: true,
          memories,
          total: memories.length,
        });
      }

      case 'tuning_levels': {
        return NextResponse.json({
          success: true,
          levels: Object.keys(TUNING_LEVELS),
          configs: TUNING_LEVELS,
        });
      }

      case 'export': {
        const store = cs.getStore();
        const exportData = {
          version: '2.0',
          exportedAt: new Date().toISOString(),
          tuning: cs.getTuning(),
          rooms: store.getAllRooms().map(room => ({
            id: room.id,
            canonical: room.canonical,
            fields: room.fields,
            meta: room.meta,
            links: room.links,
          })),
          graph: Object.fromEntries(
            Array.from(store.graph.entries()).map(([k, v]) => [k, Object.fromEntries(v)])
          ),
          anchorIds: Array.from(store.anchorIds),
          attractors: store.attractors,
        };

        return NextResponse.json({
          success: true,
          data: exportData,
          count: exportData.rooms.length,
        });
      }

      case 'code': {
        // Return all the source code files
        const fs = await import('fs');
        const path = await import('path');
        
        const codeFiles: Record<string, string> = {};
        const basePath = process.cwd();
        
        const filesToRead = [
          'src/lib/cognito/engine.ts',
          'src/app/api/cognito/route.ts',
          'src/app/api/chat/route.ts',
          'src/app/page.tsx',
          'src/lib/cognito/geodesic-retrieval.ts',
        ];
        
        for (const file of filesToRead) {
          const filePath = path.join(basePath, file);
          try {
            const content = fs.readFileSync(filePath, 'utf-8');
            codeFiles[file] = content;
          } catch {
            codeFiles[file] = '// File not found';
          }
        }

        return NextResponse.json({
          success: true,
          files: codeFiles,
        });
      }

      case 'geodesic_status': {
        try {
          const geoRetrieval = getGeodesicRetrieval();
          return NextResponse.json({
            success: true,
            geodesic: geoRetrieval.getStatus(),
          });
        } catch {
          return NextResponse.json({
            success: false,
            error: 'Geodesic retrieval not initialized. Use POST to initialize.',
          });
        }
      }

      case 'geodesic_search': {
        const query = searchParams.get('query') || '';
        const topK = parseInt(searchParams.get('topK') || '6');
        const maxHops = parseInt(searchParams.get('maxHops') || '4');

        try {
          const geoRetrieval = getGeodesicRetrieval();
          const results = geoRetrieval.geodesicBestFit(query, topK, maxHops);
          
          return NextResponse.json({
            success: true,
            results: results.map(r => ({
              id: r.room.id,
              canonical: r.room.canonical,
              kind: r.room.meta.kind,
              score: r.score,
              pathLength: r.pathLength,
              components: r.components,
              isPriorityNode: r.isPriorityNode,
            })),
            status: geoRetrieval.getStatus(),
          });
        } catch {
          // Initialize on first use
          const store = cs.getStore();
          const geoRetrieval = initGeodesicRetrieval(store, cs.getTuning());
          const results = geoRetrieval.geodesicBestFit(query, topK, maxHops);
          
          return NextResponse.json({
            success: true,
            results: results.map(r => ({
              id: r.room.id,
              canonical: r.room.canonical,
              kind: r.room.meta.kind,
              score: r.score,
              pathLength: r.pathLength,
              components: r.components,
              isPriorityNode: r.isPriorityNode,
            })),
            status: geoRetrieval.getStatus(),
          });
        }
      }

      default:
        return NextResponse.json({
          success: false,
          error: 'Unknown action. Use: status, search, recall, tick, guard, talos, graph, memories, tuning_levels, geodesic_status, geodesic_search',
        }, { status: 400 });
    }
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const cs = getCognito();

  try {
    const body = await request.json();
    const { action } = body;

    switch (action) {
      case 'add_memory': {
        const { text, kind = 'episodic', isAnchor = false, attractor = false } = body;
        if (!text) {
          return NextResponse.json({
            success: false,
            error: 'Text is required',
          }, { status: 400 });
        }

        const id = cs.addMemory(text, kind, isAnchor, attractor);
        return NextResponse.json({
          success: true,
          id,
          message: `Memory ${id} added successfully`,
        });
      }

      case 'add_page': {
        const { title, snippet, body: pageBody, url, tags = [], kind = 'page' } = body;
        if (!title || !pageBody) {
          return NextResponse.json({
            success: false,
            error: 'Title and body are required',
          }, { status: 400 });
        }

        const id = cs.addPageResult(title, snippet || '', pageBody, url || '', tags, kind);
        return NextResponse.json({
          success: true,
          id,
          message: `Page ${id} added successfully`,
        });
      }

      case 'bulk_add': {
        const { memories } = body;
        if (!Array.isArray(memories)) {
          return NextResponse.json({
            success: false,
            error: 'Memories must be an array',
          }, { status: 400 });
        }

        const ids: number[] = [];
        for (const mem of memories) {
          const id = cs.addMemory(
            mem.text,
            mem.kind || 'episodic',
            mem.isAnchor || false,
            mem.attractor || false
          );
          ids.push(id);
        }

        return NextResponse.json({
          success: true,
          ids,
          message: `${ids.length} memories added successfully`,
        });
      }

      case 'set_tuning': {
        const { tuning } = body;
        if (!TUNING_LEVELS[tuning]) {
          return NextResponse.json({
            success: false,
            error: `Invalid tuning level. Use: ${Object.keys(TUNING_LEVELS).join(', ')}`,
          }, { status: 400 });
        }

        cs.setTuning(tuning);
        return NextResponse.json({
          success: true,
          message: `Tuning set to ${tuning}`,
          tuning: cs.getTuning(),
        });
      }

      case 'reset': {
        resetSharedState(body.tuning || "Gateway");
        return NextResponse.json({
          success: true,
          message: 'CognitoSynthetica reset',
        });
      }

      case 'import': {
        const { data } = body;
        if (!data || !data.rooms) {
          return NextResponse.json({
            success: false,
            error: 'Invalid import data. Expected format: { rooms: [...] }',
          }, { status: 400 });
        }

        // Import data using shared state
        resetSharedState(data.tuning?.name || "Gateway");
        const store = getSharedStore();
        
        let importedCount = 0;
        for (const room of data.rooms) {
          try {
            // Use the raw room data to recreate the memory
            store.addRoom(
              room.canonical,
              room.meta?.kind || 'episodic',
              room.fields || {},
              room.meta || {},
              room.meta?.is_anchor || false,
              room.meta?.attractor || false
            );
            importedCount++;
          } catch {
            // Skip invalid rooms
          }
        }

        return NextResponse.json({
          success: true,
          imported: importedCount,
          message: `Imported ${importedCount} memories`,
        });
      }

      case 'import_file': {
        const { content, filename, isBase64 } = body;
        if (!content) {
          return NextResponse.json({
            success: false,
            error: 'File content is required',
          }, { status: 400 });
        }

        // Handle PDF files
        if (filename?.toLowerCase().endsWith('.pdf') || isBase64) {
          try {
            let pdfBuffer: Buffer;
            
            if (isBase64) {
              // Extract base64 data from data URL if present
              const base64Data = content.includes('base64,') 
                ? content.split('base64,')[1] 
                : content;
              pdfBuffer = Buffer.from(base64Data, 'base64');
            } else {
              pdfBuffer = Buffer.from(content, 'utf-8');
            }
            
            const parser = new PDFParse({ data: pdfBuffer });
            const textResult = await parser.getText();
            const pdfText = textResult.text;
            const numPages = textResult.numPages;
            
            // Clean up
            await parser.destroy();
            
            if (!pdfText || pdfText.trim().length === 0) {
              return NextResponse.json({
                success: false,
                error: 'Could not extract text from PDF. The PDF may be image-based or empty.',
              }, { status: 400 });
            }
            
            // Store the PDF content as a page memory with metadata
            const store = cs.getStore();
            const chunks = splitTextIntoChunks(pdfText, 1000);
            let importedCount = 0;
            
            for (let i = 0; i < chunks.length; i++) {
              const chunk = chunks[i];
              store.addRoom(
                `[PDF: ${filename}] Part ${i + 1}/${chunks.length}: ${chunk}`,
                'page',
                { 
                  filename, 
                  chunkIndex: i, 
                  totalChunks: chunks.length,
                  text: chunk,
                  source: 'pdf_upload',
                  pages: numPages
                },
                { kind: 'page', tags: ['pdf', 'document', filename] },
                false,
                false
              );
              importedCount++;
            }
            
            // Also store a summary memory
            store.addRoom(
              `Uploaded PDF document: ${filename} (${numPages} pages, ${chunks.length} memory chunks). Contains: ${pdfText.slice(0, 200)}...`,
              'semantic',
              { filename, totalPages: numPages, chunks: chunks.length },
              { kind: 'semantic', tags: ['pdf', 'document', 'summary'] },
              false,
              false
            );
            
            return NextResponse.json({
              success: true,
              imported: importedCount + 1,
              filename,
              fileType: 'pdf',
              pages: numPages,
              chunks: chunks.length,
              preview: pdfText.slice(0, 500),
              message: `Extracted and stored ${importedCount + 1} memories from PDF: ${filename}`,
            });
          } catch (pdfError) {
            console.error('PDF parsing error:', pdfError);
            return NextResponse.json({
              success: false,
              error: `Failed to parse PDF: ${pdfError instanceof Error ? pdfError.message : 'Unknown error'}`,
            }, { status: 400 });
          }
        }

        // Handle text/JSON files
        let data;
        try {
          // Try to parse as JSON
          data = JSON.parse(content);
        } catch {
          // Try to parse as JSONL (one JSON object per line)
          const lines = content.split('\n').filter((l: string) => l.trim());
          data = { rooms: lines.map((line: string) => {
            try {
              const parsed = JSON.parse(line);
              return {
                canonical: parsed.canonical || parsed.text || line,
                meta: { kind: parsed.kind || 'episodic', ...parsed.meta },
              };
            } catch {
              return { canonical: line, meta: { kind: 'episodic' } };
            }
          })};
        }

        if (!data.rooms && Array.isArray(data)) {
          data = { rooms: data };
        }

        // Import the data using shared state
        resetSharedState("Gateway");
        const store = getSharedStore();
        
        let importedCount = 0;
        const rooms = data.rooms || data.memories || [data];
        
        for (const room of rooms) {
          try {
            const text = room.canonical || room.text || room.content || String(room);
            const kind = room.meta?.kind || room.kind || 'episodic';
            store.addRoom(text, kind, room.fields || {}, room.meta || {}, false, false);
            importedCount++;
          } catch {
            // Skip invalid entries
          }
        }

        return NextResponse.json({
          success: true,
          imported: importedCount,
          filename,
          message: `Imported ${importedCount} memories from ${filename}`,
        });
      }
      
      case 'upload_document': {
        const { content, filename, fileType } = body;
        if (!content) {
          return NextResponse.json({
            success: false,
            error: 'Document content is required',
          }, { status: 400 });
        }

        const store = cs.getStore();
        
        // Handle different file types
        if (fileType === 'pdf' || filename?.toLowerCase().endsWith('.pdf')) {
          try {
            const base64Data = content.includes('base64,') 
              ? content.split('base64,')[1] 
              : content;
            const pdfBuffer = Buffer.from(base64Data, 'base64');
            const parser = new PDFParse({ data: pdfBuffer });
            const textResult = await parser.getText();
            const pdfText = textResult.text;
            await parser.destroy();
            
            if (!pdfText || pdfText.trim().length === 0) {
              return NextResponse.json({
                success: false,
                error: 'Could not extract text from PDF.',
              }, { status: 400 });
            }
            
            const chunks = splitTextIntoChunks(pdfText, 1000);
            let importedCount = 0;
            
            for (let i = 0; i < chunks.length; i++) {
              const chunk = chunks[i];
              store.addRoom(
                `[DOCUMENT: ${filename}] Part ${i + 1}/${chunks.length}: ${chunk}`,
                'page',
                { 
                  filename, 
                  chunkIndex: i, 
                  totalChunks: chunks.length,
                  text: chunk,
                  source: 'document_upload'
                },
                { kind: 'page', tags: ['document', filename] },
                false,
                false
              );
              importedCount++;
            }
            
            return NextResponse.json({
              success: true,
              imported: importedCount,
              filename,
              fileType: 'pdf',
              preview: pdfText.slice(0, 500),
            });
          } catch (error) {
            return NextResponse.json({
              success: false,
              error: `PDF processing error: ${error instanceof Error ? error.message : 'Unknown'}`,
            }, { status: 400 });
          }
        }
        
        // Handle text files
        const chunks = splitTextIntoChunks(content, 1000);
        let importedCount = 0;
        
        for (let i = 0; i < chunks.length; i++) {
          store.addRoom(
            `[DOCUMENT: ${filename}] Part ${i + 1}/${chunks.length}: ${chunks[i]}`,
            'page',
            { filename, chunkIndex: i, totalChunks: chunks.length, text: chunks[i] },
            { kind: 'page' },
            false,
            false
          );
          importedCount++;
        }
        
        return NextResponse.json({
          success: true,
          imported: importedCount,
          filename,
          fileType: fileType || 'text',
        });
      }

      default:
        return NextResponse.json({
          success: false,
          error: 'Unknown action. Use: add_memory, add_page, bulk_add, set_tuning, reset',
        }, { status: 400 });
    }
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }, { status: 500 });
  }
}
